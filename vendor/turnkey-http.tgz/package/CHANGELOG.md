# @turnkey/http

## 6.3.0

### Minor Changes

- [#1458](https://github.com/tkhq/sdk/pull/1458) [`22a6682`](https://github.com/tkhq/sdk/commit/22a6682a3a7c5ad7b192cb46ffc599e073802ccf) Author [@besler613](https://github.com/besler613) - Sync transaction history API types with the latest public API swagger.

  ### Transaction history query endpoints
  - `listEthTransactionHistory` (`POST /public/v1/query/list_eth_transaction_history`) — paginated EVM transaction history for a wallet or private-key address on a supported CAIP-2 chain.
  - `listSolTransactionHistory` (`POST /public/v1/query/list_sol_transaction_history`) — paginated Solana transaction history for a wallet or private-key address on a supported CAIP-2 chain.

  ### Pagination type update

  Transaction history pagination now uses the shared `v1Pagination` / `v1PageInfo` types instead of transaction-history-specific `v1TransactionHistoryPaginationOptions` / `v1TransactionHistoryPaginationCursors`.

  **Before:**

  ```ts
  const response = await client.listEthTransactionHistory({ ... });
  const after = response.paginationCursors.after;
  ```

  **After:**

  ```ts
  const response = await client.listEthTransactionHistory({ ... });
  const after = response.pageInfo?.endCursor;
  ```

  These surfaces are generated into `@turnkey/http`, `@turnkey/sdk-types`, `@turnkey/sdk-browser`, `@turnkey/sdk-server`, and `@turnkey/core`.

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.13

## 6.2.1

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.12

## 6.2.0

### Minor Changes

- [#1480](https://github.com/tkhq/sdk/pull/1480) [`f191ad9`](https://github.com/tkhq/sdk/commit/f191ad98d5bd194a12045d9b0c562abccb07169a) Thanks [@moe-dev](https://github.com/moe-dev)! - Expose `createSwapQuote` (`ACTIVITY_TYPE_CREATE_SWAP_QUOTE`) and `executeSwap` (`ACTIVITY_TYPE_EXECUTE_SWAP_V2`) on the high-level SDK clients. `createSwapQuote` takes `signWith`, CAIP-19 tokens, amount, and optional `slippageBps`, and returns provider quotes. `executeSwap` is quote-bound: pass `quoteId` plus the exact quoted amounts (`quotedOutputAmount`, `minOutputAmount`, `sponsor`); the signer is derived from the quote. Poll with `getSwapStatus` using the returned `swapRequestId`.

  Also align transaction-history list responses with standard pagination (`v1Pagination` / `pageInfo`) instead of the previous transaction-history-specific cursor types.

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.11

## 6.1.0

### Minor Changes

- [#1475](https://github.com/tkhq/sdk/pull/1475) [`4a20057`](https://github.com/tkhq/sdk/commit/4a20057b37d6081c0c38c0a4840affcd16140d47) Thanks [@moe-dev](https://github.com/moe-dev)! - Sync generated API clients and types with the latest public API swagger.

  ### New query endpoints
  - `getClaimEarnFeesStatus` (`POST /public/v1/query/get_claim_earn_fees_status`) — poll Earn fee-claim status by the `claimRequestId` returned from `ClaimEarnFees`. Response status is `PENDING` | `COMPLETED` | `FAILED`, with optional `claimTxHash` / `error`.
  - `getSwapStatus` (`POST /public/v1/query/get_swap_status`) — poll swap status by the `swapRequestId` returned from `ExecuteSwap`. Covers same-chain and cross-chain swaps, and returns provider, input/output tokens and amounts, origin/destination tx hashes, optional refund info on failure, and normalized error details.

  ### New submit endpoints / activities
  - `claimSwapFees` (`POST /public/v1/submit/claim_swap_fees`, `ACTIVITY_TYPE_CLAIM_SWAP_FEES`) — claim swap fees through the activity pipeline; result includes a Relay `requestId`.
  - `ethUndelegate7702` (`POST /public/v1/submit/eth_undelegate_7702`, `ACTIVITY_TYPE_ETH_UNDELEGATE_7702`) — submit an EIP-7702 undelegation for a wallet/private-key address on a supported CAIP-2 chain. Optional nonce / gas / fee fields; result returns a `sendTransactionStatusId` for polling.
  - `upsertSwapConfig` (`POST /public/v1/submit/upsert_swap_config`, `ACTIVITY_TYPE_UPSERT_SWAP_CONFIG`) — enable or update org swap config (`feeReceiverWalletAddress`, `feeBps`, and Enterprise-only `stableFeeBps` for stablecoin pairs).
  - `createSwapQuote` (`ACTIVITY_TYPE_CREATE_SWAP_QUOTE`) — request provider quotes for a swap (`signWith`, CAIP-19 `inputToken` / `outputToken`, `inputAmount`, optional `slippageBps`). Returns one or more `v1SwapQuote` values; pass `quoteId` into execute-swap v2.

  ### Related activity / type updates
  - `ACTIVITY_TYPE_EXECUTE_SWAP_V2` / `v1ExecuteSwapIntentV2` — quote-bound swap execution. Takes `quoteId` plus the exact quoted amounts (`inputAmount`, `quotedOutputAmount`, `minOutputAmount`, `sponsor`), with optional `evmNonce` / `recentBlockhash` / `gasStationNonce`. Signer is derived from the quote and must not be resupplied. Result still exposes `swapRequestId` for `getSwapStatus`.
  - `ACTIVITY_TYPE_UPDATE_WALLET_ACCOUNT_NAME` / `v1UpdateWalletAccountNameIntent` — rename a wallet account by `walletAccountId`.
  - Supporting swap types: `v1SwapQuote`, `v1SwapError`, `v1SwapRefund`.
  - CAIP-2 enums used by transaction intents (including undelegation) now include `eip155:143`.

  These surfaces are generated into `@turnkey/http`, `@turnkey/sdk-types`, `@turnkey/sdk-browser`, `@turnkey/sdk-server`, and `@turnkey/core`.

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.10

## 6.0.0

### Major Changes

- [#1448](https://github.com/tkhq/sdk/pull/1448) [`de5e169`](https://github.com/tkhq/sdk/commit/de5e1692ab79c18d898326e76777fa7ea54df812) Thanks [@Bijan-Massoumi](https://github.com/Bijan-Massoumi)! - Add Solana send-transaction v2 support for transactions requiring multiple Turnkey signers.

  `solSendTransaction()` now uses `ACTIVITY_TYPE_SOL_SEND_TRANSACTION_V2`. The v2 intent accepts an ordered `signWiths` array for transactions requiring multiple Turnkey signers, and its full unsigned transaction wire format is hex-encoded.

  **Before:**

  ```ts
  await client.solSendTransaction({
    unsignedTransaction: unsignedTransactionBase64,
    signWith: signerAddress,
    caip2,
    sponsor,
  });
  ```

  **After:**

  ```ts
  await client.solSendTransaction({
    unsignedTransaction: unsignedTransactionHex,
    signWiths: [signerAddress],
    caip2,
    sponsor,
  });
  ```

### Minor Changes

- [#1452](https://github.com/tkhq/sdk/pull/1452) [`b447497`](https://github.com/tkhq/sdk/commit/b447497e965b0b1df02d2294e87f89cedb761719) Author [@ericvelazquez](https://github.com/ericvelazquez) - Add Turnkey Earn APIs (early access) to the high-level SDK clients: `earnVaults`, `earnEnabledVaults`, `earnPositions`, `earnDeposit`, `earnDepositStatus`, `earnWithdraw`, `earnWithdrawStatus`, `earnDeployWrapper`, and `earnDeployStatus`.

  The Earn read endpoints live under `/query/` but aren't named `get`/`list`/`test`/`validate`, so each package's codegen pins `/query/earn_*` to query methods by path. `@turnkey/http` gains the previously-missing `earnDeployStatus` so its generated Earn surface matches the other packages.

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.9

## 5.0.0

### Major Changes

- [#1433](https://github.com/tkhq/sdk/pull/1433) [`cd1af93`](https://github.com/tkhq/sdk/commit/cd1af93c41a3f41c3c68589cfa6cfe17c1812c2f) Author [@amircheikh](https://github.com/amircheikh) - - Synced with Mono v2026.7.3
  - `EthSendTransaction()` function call now uses `ACTIVITY_TYPE_ETH_SEND_TRANSACTION_V2`. This activity allows for multiple eth calls to be batched together via the new `calls` array. This means the intent for the activity has now changed.

  **Before:**

  ```ts
  await client.ethSendTransaction({
    from,
    caip2,
    to,
    value,
    data,
  });
  ```

  **After:**

  ```ts
  await client.ethSendTransaction({
    from,
    caip2,
    calls: [{ to, value, data }],
  });
  ```

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.8

## 4.1.1

### Patch Changes

- [#1365](https://github.com/tkhq/sdk/pull/1365) [`325fded`](https://github.com/tkhq/sdk/commit/325fdedf2c647c9a93f28aa7355b1ff0053689f9) Author [@MasterHW](https://github.com/MasterHW) - Update example links in READMEs and docs to reflect new category-based directory structure under `examples/`

## 4.1.0

### Minor Changes

- [#1324](https://github.com/tkhq/sdk/pull/1324) [`f505818`](https://github.com/tkhq/sdk/commit/f505818e121c137d290156a32918a884ba80e5f5) Author [@janjakubnanista](https://github.com/janjakubnanista) - ### Breaking/Behavioral Changes

  #### `nonce` parameter in `oauth2Authenticate` is now required

  ```ts
  # Before
  apiClient.oauth2Authenticate({
    oauth2CredentialId: ...,
    authCode: ...,
    redirectUri: ...,
    codeVerifier: ...,
    bearerTokenTargetPublicKey: ...,
    // nonce can be undefined
    nonce: undefined
  })

  # After
  apiClient.oauth2Authenticate({
    oauth2CredentialId: ...,
    authCode: ...,
    redirectUri: ...,
    codeVerifier: ...,
    bearerTokenTargetPublicKey: ...,
    // nonce is required
    nonce: ""
  })
  ```

  #### Solana transactions in Transaction Management are now limited to the following `caip2` values:
  - `solana:mainnet`
  - `solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp`
  - `solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d`
  - `solana:devnet`
  - `solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1`
  - `solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1wcaWoxPkrZBG`

  ### New SDK methods

  #### TVC

  These methods will only work if you are part of the [TVC beta](https://www.turnkey.com/turnkey-verifiable-cloud#waitlist)
  - `getTvcApp`
  - `getTvcDeployment`
  - `getTvcAppDeployments`
  - `getTvcApps`
  - `validateTvcImage`
  - `createTvcApp`
  - `createTvcDeployment`
  - `createTvcManifestApprovals`
  - `deleteTvcAppAndDeployments`
  - `deleteTvcDeployment`
  - `restoreTvcDeployment`
  - `updateTvcAppLiveDeployment`

  #### Spark protocol support
  - `sparkClaimTransfer`
  - `sparkPrepareLightningReceive`
  - `sparkPrepareTransfer`
  - `sparkSignFrost`

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.7

## 4.0.0

### Major Changes

- [#1250](https://github.com/tkhq/sdk/pull/1250) [`6128132`](https://github.com/tkhq/sdk/commit/6128132d910f658cdf83ecc1dec6598eb20c008a) Author [@moeodeh3](https://github.com/moeodeh3) - ### `INIT_OTP`

  `ACTIVITY_TYPE_INIT_OTP_V2` → `ACTIVITY_TYPE_INIT_OTP_V3`

  **What changed:** Added required `otpEncryptionTargetBundle` to the result.

  ```ts
  // before — v1InitOtpResult
  {
    otpId: string;
  }

  // after — v1InitOtpResultV2
  {
    otpId: string;
    otpEncryptionTargetBundle: string; // new
  }
  ```

  ***

  ### `VERIFY_OTP`

  `ACTIVITY_TYPE_VERIFY_OTP` → `ACTIVITY_TYPE_VERIFY_OTP_V2`

  **What changed:** Replaced plaintext `otpCode` + `publicKey` with a single `encryptedOtpBundle`.

  Instead of sending the OTP code in plaintext, you now HPKE-encrypt it (along with your public key) to Turnkey's enclave using the `otpEncryptionTargetBundle` returned by `initOtp`. This ensures the OTP code never leaves the client in plaintext.

  Use `encryptOtpCodeToBundle` from `@turnkey/crypto` to build the bundle:

  ```ts
  import { encryptOtpCodeToBundle } from "@turnkey/crypto";

  const { otpId, otpEncryptionTargetBundle } = await client.initOtp({ ... });

  // After the user enters their OTP code:
  const encryptedOtpBundle = await encryptOtpCodeToBundle(
    otpCode,                    // the code the user entered
    otpEncryptionTargetBundle,  // from the initOtp response
    publicKey,                  // your target public key
  );

  await client.verifyOtp({
    otpId,
    encryptedOtpBundle,
  });
  ```

  ```ts
  // before — v1VerifyOtpIntent
  {
    otpId: string;
    otpCode: string;           // removed
    expirationSeconds?: string;
    publicKey?: string;         // removed
  }

  // after — v1VerifyOtpIntentV2
  {
    otpId: string;
    encryptedOtpBundle: string; // new — replaces otpCode + publicKey
    expirationSeconds?: string;
  }
  ```

  ***

  ### `OTP_LOGIN`

  `ACTIVITY_TYPE_OTP_LOGIN` → `ACTIVITY_TYPE_OTP_LOGIN_V2`

  **What changed:** `clientSignature` promoted from optional to required.

  ```ts
  // before — v1OtpLoginIntent
  {
    verificationToken: string;
    publicKey: string;
    expirationSeconds?: string;
    invalidateExisting?: boolean;
    clientSignature?: v1ClientSignature; // optional
  }

  // after — v1OtpLoginIntentV2
  {
    verificationToken: string;
    publicKey: string;
    expirationSeconds?: string;
    invalidateExisting?: boolean;
    clientSignature: v1ClientSignature;  // now required
  }
  ```

  ***

  ### `CREATE_OAUTH_PROVIDERS`

  `ACTIVITY_TYPE_CREATE_OAUTH_PROVIDERS` → `ACTIVITY_TYPE_CREATE_OAUTH_PROVIDERS_V2`

  **What changed:** Added `oidcClaims` as a new option alongside `oidcToken`; you must provide exactly one. This updated type feeds into the `CREATE_SUB_ORGANIZATION` and `CREATE_USERS` changes below.

  ```ts
  // before — v1OauthProviderParams
  {
    providerName: string;
    oidcToken: string;
  }

  // after — v1OauthProviderParamsV2
  {
    providerName: string;
  } & (
    | { oidcToken: string }
    | { oidcClaims: { iss: string; sub: string; aud: string } }
  )
  ```

  ***

  ### `CREATE_SUB_ORGANIZATION`

  `ACTIVITY_TYPE_CREATE_SUB_ORGANIZATION_V7` → `ACTIVITY_TYPE_CREATE_SUB_ORGANIZATION_V8`

  **What changed:** `rootUsers` items updated from `v1RootUserParamsV4` → `v1RootUserParamsV5`, which updates `oauthProviders` from `v1OauthProviderParams` → `v1OauthProviderParamsV2`.

  ```ts
  // before — v1RootUserParamsV4
  {
    userName: string;
    userEmail?: string;
    userPhoneNumber?: string;
    apiKeys: v1ApiKeyParamsV2[];
    authenticators: v1AuthenticatorParamsV2[];
    oauthProviders: {              // v1OauthProviderParams
      providerName: string;
      oidcToken: string;           // was required
    }[];
  }

  // after — v1RootUserParamsV5
  {
    userName: string;
    userEmail?: string;
    userPhoneNumber?: string;
    apiKeys: v1ApiKeyParamsV2[];
    authenticators: v1AuthenticatorParamsV2[];
    oauthProviders: ({             // v1OauthProviderParamsV2
      providerName: string;
    } & (
      | { oidcToken: string }
      | { oidcClaims: { iss: string; sub: string; aud: string } }
    ))[];
  }
  ```

  ***

  ### `CREATE_USERS`

  `ACTIVITY_TYPE_CREATE_USERS_V3` → `ACTIVITY_TYPE_CREATE_USERS_V4`

  **What changed:** `users` items updated from `v1UserParamsV3` → `v1UserParamsV4`, which updates `oauthProviders` from `v1OauthProviderParams` → `v1OauthProviderParamsV2`.

  ```ts
  // before — v1UserParamsV3
  {
    userName: string;
    userEmail?: string;
    userPhoneNumber?: string;
    apiKeys: v1ApiKeyParamsV2[];
    authenticators: v1AuthenticatorParamsV2[];
    oauthProviders: {              // v1OauthProviderParams
      providerName: string;
      oidcToken: string;           // was required
    }[];
    userTags: string[];
  }

  // after — v1UserParamsV4
  {
    userName: string;
    userEmail?: string;
    userPhoneNumber?: string;
    apiKeys: v1ApiKeyParamsV2[];
    authenticators: v1AuthenticatorParamsV2[];
    oauthProviders: ({             // v1OauthProviderParamsV2
      providerName: string;
    } & (
      | { oidcToken: string }
      | { oidcClaims: { iss: string; sub: string; aud: string } }
    ))[];
    userTags: string[];
  }
  ```

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.6

## 3.18.1

### Patch Changes

- [#1269](https://github.com/tkhq/sdk/pull/1269) [`ef66673`](https://github.com/tkhq/sdk/commit/ef6667325d210c8aa0ea4c1d11d834ff28ddb66c) Author [@ethankonk](https://github.com/ethankonk) - Sync with v2026.4.5 of mono

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.5

## 3.18.0

### Minor Changes

- [#1252](https://github.com/tkhq/sdk/pull/1252) [`46b4d2f`](https://github.com/tkhq/sdk/commit/46b4d2fa807fb87d06bb606623ba1f86582aa4ef) Author [@ethankonk](https://github.com/ethankonk) - Sync as per mono v2026.3.6

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.4

## 3.17.1

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.3

## 3.17.0

### Minor Changes

- [#1206](https://github.com/tkhq/sdk/pull/1206) [`58e04e5`](https://github.com/tkhq/sdk/commit/58e04e5856626d9d2593abb61d8ca32d8ccbb833) Author [@DeRauk](https://github.com/DeRauk) - Adds sdk methods for the GetWalletAddressBalances and ListSupportedAssets apis.

### Patch Changes

- [#1201](https://github.com/tkhq/sdk/pull/1201) [`1f6e240`](https://github.com/tkhq/sdk/commit/1f6e2403fca1fd9cbca646f88c88dbc49ddb0c34) Author [@ethankonk](https://github.com/ethankonk) - Synced with Mono v2026.2.0

- [#1197](https://github.com/tkhq/sdk/pull/1197) [`7458b7c`](https://github.com/tkhq/sdk/commit/7458b7cd6fc64796b376e3374b7c2ed79467459c) Thanks [@moe-dev](https://github.com/moe-dev)! - Add support for SolSendTransaction and associated abstractions

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.2

## 3.16.3

### Patch Changes

- [#1194](https://github.com/tkhq/sdk/pull/1194) [`dced9db`](https://github.com/tkhq/sdk/commit/dced9dbbd8ea533442e19e45ce36e6a05a45a555) Author [@moeodeh3](https://github.com/moeodeh3) - Add `Content-Type: application/json` header to all Turnkey API requests. The missing header caused "Network request failed" errors on React Native, intermittent for some setups and consistent for others, where OkHttp-backed fetch can reject `POST` requests without an explicit `Content-Type`. See also: https://github.com/JakeChampion/fetch/issues/823

  Special thanks to @jrmykolyn and @niroshanS for helping identify and debug this issue

## 3.16.2

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.1

## 3.16.1

### Patch Changes

- Updated dependencies [[`91d6a9e`](https://github.com/tkhq/sdk/commit/91d6a9eb1b9ac9e21745749615ac7a7be66f5cf6)]:
  - @turnkey/api-key-stamper@0.6.0

## 3.16.0

### Minor Changes

- [#1153](https://github.com/tkhq/sdk/pull/1153) [`78ec1d9`](https://github.com/tkhq/sdk/commit/78ec1d9afcafde3ca7107fc720323d486d6afaea) Thanks [@moe-dev](https://github.com/moe-dev)! - Update as per mono v2025.12.3.

  ### Behavioral Changes
  - `appName` is now **required**:
    - In `emailCustomization` for Email Auth activities
    - At the top-level intent for OTP activities
  - Auth proxy endpoints are **not affected**

  ### Activity Version Bumps

  The following activity types have been versioned:
  - `ACTIVITY_TYPE_INIT_OTP` → `ACTIVITY_TYPE_INIT_OTP_V2`
  - `ACTIVITY_TYPE_INIT_OTP_AUTH_V2` → `ACTIVITY_TYPE_INIT_OTP_AUTH_V3`
  - `ACTIVITY_TYPE_EMAIL_AUTH_V2` → `ACTIVITY_TYPE_EMAIL_AUTH_V3`
  - `ACTIVITY_TYPE_INIT_USER_EMAIL_RECOVERY` -> `ACTIVITY_TYPE_INIT_USER_EMAIL_RECOVERY_V2`

## 3.15.0

### Minor Changes

- [#1072](https://github.com/tkhq/sdk/pull/1072) [`67b03a5`](https://github.com/tkhq/sdk/commit/67b03a5d9ab1b6eabfb0b41938ac91365b5dcd9b) Thanks [@moe-dev](https://github.com/moe-dev)! - Bump packages as per mono v2025.11.0

## 3.14.0

### Minor Changes

- [#1058](https://github.com/tkhq/sdk/pull/1058) [`9fbd5c4`](https://github.com/tkhq/sdk/commit/9fbd5c459782dc3721dd0935d0a4458babce258b) Author [@moeodeh3](https://github.com/moeodeh3) - Update per mono release `v2025.10.10-hotfix.2`

## 3.13.1

### Patch Changes

- [#1016](https://github.com/tkhq/sdk/pull/1016) [`9df42ad`](https://github.com/tkhq/sdk/commit/9df42adc02c7ff77afba3b938536e79b57882ef1) Author [@amircheikh](https://github.com/amircheikh) - Synced API as per mono v2025.10.2

## 3.13.0

### Minor Changes

- [#977](https://github.com/tkhq/sdk/pull/977) [`4567059`](https://github.com/tkhq/sdk/commit/45670598f102223925b87a5295edca15a6ce8241) Author [@besler613](https://github.com/besler613) - OAuth2Authenticate now supports returning the encrypted bearer token via the optional `bearerTokenTargetPublicKey` request parameter (mono release v2025.9.5)

## 3.12.1

### Patch Changes

- [#958](https://github.com/tkhq/sdk/pull/958) [`5a96fe8`](https://github.com/tkhq/sdk/commit/5a96fe80db4c4c45e09ad8c613695ee4c2b8e51f) Author [@amircheikh](https://github.com/amircheikh) - - Synced api with mono

## 3.12.0

### Minor Changes

- Updated dependencies [[`fc1d6e2`](https://github.com/tkhq/sdk/commit/fc1d6e2d26f4a53116633e9e8cccccd792267f4e), [`fc1d6e2`](https://github.com/tkhq/sdk/commit/fc1d6e2d26f4a53116633e9e8cccccd792267f4e), [`4880f26`](https://github.com/tkhq/sdk/commit/4880f26a4dd324c049bff7f35284098ccfc55823), [`c6ee323`](https://github.com/tkhq/sdk/commit/c6ee3239c389a7bbbbb23610c84b883ed298f95c), [`c6ee323`](https://github.com/tkhq/sdk/commit/c6ee3239c389a7bbbbb23610c84b883ed298f95c), [`c6ee323`](https://github.com/tkhq/sdk/commit/c6ee3239c389a7bbbbb23610c84b883ed298f95c), [`06347ad`](https://github.com/tkhq/sdk/commit/06347adfa08fb0867c350e43821d0fed06c49624), [`6bfcbc5`](https://github.com/tkhq/sdk/commit/6bfcbc5c098e64ab1d115518733b87cfc1653e17)]:
  - @turnkey/encoding@0.6.0
  - @turnkey/webauthn-stamper@0.6.0
  - @turnkey/api-key-stamper@0.5.0

## 3.11.1-beta.0

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.6
  - @turnkey/api-key-stamper@0.5.0-beta.6

## 3.11.0

### Minor Changes

- [#879](https://github.com/tkhq/sdk/pull/879) [`026264c`](https://github.com/tkhq/sdk/commit/026264c55aa16342c8925af0bdcdf72dc00e5158) Author [@zkharit](https://github.com/zkharit) - Update packages to include new activities as of the newest release (mono v2025.8.10)

## 3.10.0-beta.2

### Minor Changes

- SDK beta release @turnkey/react-wallet-kit @turnkey/core

### Patch Changes

- Updated dependencies []:
  - @turnkey/webauthn-stamper@0.6.0-beta.0
  - @turnkey/api-key-stamper@0.5.0-beta.5
  - @turnkey/encoding@0.6.0-beta.5

## 3.10.0-beta.1

### Minor Changes

- @turnkey/react-wallet-kit and @turnkey/core beta-3 release

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.4
  - @turnkey/api-key-stamper@0.4.8-beta.4

## 3.10.0-beta.0

### Minor Changes

- @turnkey/react-wallet-kit and @turnkey/core beta-3 release

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.3
  - @turnkey/api-key-stamper@0.4.8-beta.3

## 3.10.0

### Minor Changes

- [#861](https://github.com/tkhq/sdk/pull/861) [`5d8be2d`](https://github.com/tkhq/sdk/commit/5d8be2d0329070c7aa025dddb1b28f04257ae4e6) Author [@amircheikh](https://github.com/amircheikh) - Synced as per mono 2025.8.4

## 3.9.0

### Minor Changes

- [#834](https://github.com/tkhq/sdk/pull/834) [`8b39dba`](https://github.com/tkhq/sdk/commit/8b39dbabf68d3e376b5b07f26960d5b61ae87fa9) Author [@moeodeh3](https://github.com/moeodeh3) - Update per mono release v2025.8.3-hotfix.0

## 3.8.1-beta.2

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.2
  - @turnkey/api-key-stamper@0.4.8-beta.2

## 3.8.1-beta.1

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.1
  - @turnkey/api-key-stamper@0.4.8-beta.1

## 3.8.1-beta.0

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@1.0.0-beta.0
  - @turnkey/api-key-stamper@0.4.8-beta.0

## 3.8.0

### Minor Changes

- [#826](https://github.com/tkhq/sdk/pull/826) [`f83f25b`](https://github.com/tkhq/sdk/commit/f83f25ba33ef15dbd66723531eebe2fd00f43ac0) Author [@turnekybc](https://github.com/turnekybc) - Update per mono release v2025.8.1

## 3.7.0

### Minor Changes

- [#651](https://github.com/tkhq/sdk/pull/651) [`81e355c`](https://github.com/tkhq/sdk/commit/81e355c9a8321feffcac056916b65139cf35eeed) Author [@turnekybc](https://github.com/turnekybc) - Add Coinbase & MoonPay Fiat Onramp. View the [Fiat Onramp feature docs](https://docs.turnkey.com/wallets/fiat-on-ramp).

## 3.6.0

### Minor Changes

- [#782](https://github.com/tkhq/sdk/pull/782) [`e90a478`](https://github.com/tkhq/sdk/commit/e90a478c9208d858b1144df9b2c2c7ba956c406e) Thanks [@r-n-o](https://github.com/r-n-o)! - Release v2025.7.16

## 3.5.1

### Patch Changes

- [#763](https://github.com/tkhq/sdk/pull/763) [`cb13c26`](https://github.com/tkhq/sdk/commit/cb13c26edb79a01ab651e3b2897334fd154b436a) Author [@andrewkmin](https://github.com/andrewkmin) - Release per mono v2025.7.1. This release contains the following API changes:
  - Introduction of `SmartContractInterfaces`: we've now exposed endpoints for uploading ABIs and IDLs to help secure EVM and Solana signing flows. For more information, see our docs [here](https://docs.turnkey.com/concepts/policies/smart-contract-interfaces)

## 3.5.0

### Minor Changes

- [#704](https://github.com/tkhq/sdk/pull/704) [`5f3dd98`](https://github.com/tkhq/sdk/commit/5f3dd9814650308b3bf3198168c453e7b1a98efd) Author [@amircheikh](https://github.com/amircheikh) - Added `name` field to constructor. `isHttpClient` now uses this new field to complete the check. This fixes a bug where `isHttpClient` would fail the check under certain production environments.

  Synced with mono 2025.6.10 to include the following endpoints:

  `update_user_email`: Update a User's email in an existing Organization

  `update_user_name`: Update a User's name in an existing Organization

  `update_user_phone_number`: Update a User's phone number in an existing Organization

### Patch Changes

- Updated dependencies [[`7625df0`](https://github.com/tkhq/sdk/commit/7625df0538002c3455bd5862211210e38472e164)]:
  - @turnkey/api-key-stamper@0.4.7

## 3.4.2

### Patch Changes

- [#665](https://github.com/tkhq/sdk/pull/665) [`be0a621`](https://github.com/tkhq/sdk/commit/be0a621fb962bd51d2df1a1e79f5260d7c696772) Author [@amircheikh](https://github.com/amircheikh) - Exposed `isHttpClient` function for determining if a passed in client is from turnkey/http

## 3.4.1

### Patch Changes

- [#663](https://github.com/tkhq/sdk/pull/663) [`593de2d`](https://github.com/tkhq/sdk/commit/593de2d9404ec8cf53426f9cf832c13eefa3fbf2) Thanks [@moe-dev](https://github.com/moe-dev)! - Update to endpoints as per mono v2025.5.7. Add V5 TON address format generation. Non breaking

- Updated dependencies [[`5afbe51`](https://github.com/tkhq/sdk/commit/5afbe51949bdd1997fad083a4c1e4272ff7409dc), [`40c4035`](https://github.com/tkhq/sdk/commit/40c40359ec7096d0bca39ffc93e89361b3b11a1a)]:
  - @turnkey/webauthn-stamper@0.5.1
  - @turnkey/encoding@0.5.0
  - @turnkey/api-key-stamper@0.4.6

## 3.4.0

### Minor Changes

- Added new authentication activities:
  - STAMP_LOGIN: Handles authentication flows for passkeys, wallet logins, and session refresh. Initiated by sub-organizations; returns a session JWT.
  - INIT_OTP: Initiates sending a 6–9 digit or bech32 alphanumeric OTP to an email or phone. Initiated by the parent organization.
  - VERIFY_OTP: Verifies the OTP and returns a verification token. Initiated by the parent organization.
  - OTP_LOGIN: Completes OTP-based authentication by verifying a tokenized OTP challenge and establishing a session. Initiated by the parent organization; returns a session JWT.
  - OAUTH_LOGIN: Finalizes OAuth-based logins from third-party OIDC providers. Initiated by the parent organization; returns a session JWT.

## 3.3.0

### Minor Changes

- 25ca339: Adding replyToEmailAddress field for specifying reply-to when using a customer sender

## 3.2.0

### Minor Changes

- 3f6e415: Update per mono v2025.4.5
  - Introduces Tron transaction parsing and policy engine support. For more information, take a look at our [docs](https://docs.turnkey.com/networks/tron)

### Patch Changes

- Updated dependencies [4d1d775]
  - @turnkey/api-key-stamper@0.4.5

## 3.1.0

### Minor Changes

- 3e4a482: Release per mono v2025.4.4
  - Adds parsing and policy engine support for Ethereum Type 3 (EIP-4844) and Type 4 (EIP-7702) transactions. There is no change to any signing interface or API; you simply can now use Turnkey's signing endpoints to sign those transaction types. See [with-viem](https://github.com/tkhq/sdk/blob/main/examples/with-viem/) for examples.
  - New wallet account creations will now automatically derive the underlying derived account's public key. For example: previously, if derived an Ethereum wallet account, you would get the resulting Ethereum address (`0x...`). If you also wanted the public key associated with that underlying key, you would've had to derive an additional wallet account with `ADDRESS_FORMAT_COMPRESSED`. Now, this will automatically be derived for you. It is now a property that has been added to the wallet account primitive (i.e. accessible via `walletAccount.publicKey`).

## 3.0.0

### Major Changes

- f94d36e: Remove deprecated TurnkeyApiService. TurnkeyApi should be used instead.

### Minor Changes

- d1083bd: New activity `INIT_OTP_AUTH_V2` which allows alphanumeric boolean and otpLength (6-9) to be passed

- This release introduces the `INIT_OTP_AUTH_V2` activity. The difference between it and `INIT_OTP_AUTH` is that it can now accept `alphanumeric` and `otpLength` for selecting crockford bech32 alphanumeric codes and the length of those codes. By default alphanumeric = true, otpLength = 9

- This release introduces `sendFromEmailSenderName` to `INIT_OTP_AUTH`, `INIT_OTP_AUTH_V2`, `EMAIL_AUTH` and `EMAIL_AUTH_V2`. This is an optional custom sender name for use with sendFromEmailAddress; if left empty, will default to 'Notifications'.

## 2.22.0

### Minor Changes

- ecdb29a: Update API as per mono v2025.3.2
  - This release introduces the `CREATE_USERS_V3` activity. The difference between it and `CREATE_USERS_V2` is that it can now accept `userPhoneNumber` and `oauthProviders`. In total, it accepts the following parameters:

  ```javascript
  /** @description A list of Users. */
  users: {
    /** @description Human-readable name for a User. */
    userName: string;
    /** @description The user's email address. */
    userEmail?: string;
    /** @description The user's phone number in E.164 format e.g. +13214567890 */
    userPhoneNumber?: string;
    /** @description A list of API Key parameters. This field, if not needed, should be an empty array in your request body. */
    apiKeys: definitions["v1ApiKeyParamsV2"][];
    /** @description A list of Authenticator parameters. This field, if not needed, should be an empty array in your request body. */
    authenticators: definitions["v1AuthenticatorParamsV2"][];
    /** @description A list of Oauth providers. This field, if not needed, should be an empty array in your request body. */
    oauthProviders: definitions["v1OauthProviderParams"][];
    /** @description A list of User Tag IDs. This field, if not needed, should be an empty array in your request body. */
    userTags: string[];
  }
  ```

  See [source code](https://github.com/tkhq/sdk/blob/60c0c03440785b841d1f6f393612046423dc665f/packages/http/src/__generated__/services/coordinator/public/v1/public_api.types.ts#L2894-L2909) to view details on the nested types.

## 2.21.0

### Minor Changes

- 56a307e: Update API to mono v2025.3.0
  - This release introduces an `invalidateExisting` flag to the `CreateReadWriteSession` and `Oauth` activities. If enabled, this will invalidate existing read-write and oauth API keys. This is useful in scenarios where a user attempts to create numerous `ReadWrite` or `Oauth` sessions. Because our API caps the number of session keys associated with a user, this flag can clear all other existing session keys of that specific type (e.g. setting `invalidateExisting: true` for `CreateReadWriteSession` will invalidate all previously created read-write session keys)

## 2.20.0

### Minor Changes

- 3c44c4a: Updates per mono release v2025.2.2

## 2.19.0

### Minor Changes

- 57f9cb0: Update endpoints - surface `GetWalletAccount`. This endpoint takes in the following args:
  ```javascript
  /** @description Unique identifier for a given Organization. */
  organizationId: string;
  /** @description Unique identifier for a given Wallet. */
  walletId: string;
  /** @description Address corresponding to a Wallet Account. */
  address?: string;
  /** @description Path corresponding to a Wallet Account. */
  path?: string;
  ```

## 2.18.0

### Minor Changes

- 6695af2: Update per mono release v2025.1.11

## 2.17.3

### Patch Changes

- 053fbfb: Update mono dependencies

## 2.17.2

### Patch Changes

- Updated dependencies [2d5977b]
  - @turnkey/api-key-stamper@0.4.4

## 2.17.1

### Patch Changes

- 538d4fc: Update api endpoints - NEW: User verification, SMS customization params

## 2.17.0

### Minor Changes

- 78bc39c: Add default accounts for various address types
  - Add wallet account ID to list wallets endpoint

## 2.16.0

### Minor Changes

- 4df8914: Version bump corresponding to mono release v2024.10.10.
  - Improved error message for duplicate activity submission
  - Address derivation support for DOGE, TON, SEI, XLM
  - Fix server side error if sub_org doesn’t have email and/or phone number

## 2.15.0

### Minor Changes

- 9ebd062: Release OTP functionality

## 2.14.2

### Patch Changes

- 96d7f99: Update dependencies
- Updated dependencies [e5c4fe9]
  - @turnkey/encoding@0.4.0
  - @turnkey/api-key-stamper@0.4.3

## 2.14.1

### Patch Changes

- ff059d5: Update dependencies
- Updated dependencies [93666ff]
  - @turnkey/encoding@0.3.0
  - @turnkey/api-key-stamper@0.4.2

## 2.14.0

### Minor Changes

- 848f8d3: Add new helpers and update types and errors
  - `getSignatureFromActivity` returns the signature corresponding to a completed activity
  - `getSignedTransactionFromActivity` returns the signed transaction corresponding to a completed activity
  - `assertActivityCompleted` checks the state of an activity and throws an error if the activity either requires consensus or is otherwise not yet completed
  - `TERMINAL_ACTIVITY_STATUSES` is a const containing all terminal activity statuses. Useful for checking on an activity
  - `TurnkeyActivityError` now uses `undefined` instead of `null`
  - Export some additional types: `TActivity`, `TActivityId`, `TActivityStatus`, `TActivityType`

## 2.13.0

### Minor Changes

- 93dee46: Add create read write session v2 which allows for user targeting directly from stamp or optional userId in intent

## 2.12.3

### Patch Changes

- e2f2e0b: Added two new endpoints for deleting private keys and deleting wallets

## 2.12.2

### Patch Changes

- 2d7e5a9: fix a (currently unused) return value

- Updated dependencies
  - @turnkey/api-key-stamper@0.4.1
  - @turnkey/encoding@0.2.1

## 2.12.1

### Patch Changes

- f17a229: Update to oauth related endpoints to drop jwks uri from oauth providers

## 2.12.0

### Minor Changes

- Add Email Auth V2 - Optional invalidate exisiting Email Authentication API keys

## 2.11.0

### Minor Changes

- Update to use new endpoints. Including CREATE_READ_WRITE_SESSION which allows one shot passkey sessions (returns org information and a credential bundle) and CREATE_API_KEYS_V2 which allows a curve type to be passed (SECP256K1 or P256)

## 2.10.0

### Minor Changes

- 7a9ce7a: Sync 2024.3.16

## 2.9.1

### Patch Changes

- Update generated files to latest release: optional pagination options were added to list sub-organization and list wallet account endpoints.

## 2.9.0

### Minor Changes

- 83b62b5: Sync types for latest release

## 2.8.0

### Minor Changes

- 46a7d90: Update to v2024.2.1 API: add activities to initialize wallet import, import wallet, delete users, delete private key tags, delete user tags, and list sub-organizations

## 2.7.1

### Patch Changes

- Update to v2024.2.0 API types: `mnemonicLength` is now a number instead of a string

## 2.7.0

### Minor Changes

- Introduce and reference `@turnkey/encoding` to consolidate utility functions
- Updated dependencies ([c3b423b], [d73725b])
  - @turnkey/webauthn-stamper@0.5.0
  - @turnkey/api-key-stamper@0.4.0
  - @turnkey/encoding@0.1.0

## 2.6.2

### Patch Changes

- b45a9ac: Include package version in request headers
- f9d636c: Export VERSION from turnkey/http

## 2.6.1

### Patch Changes

- 52e2389: Revert version export (#186 and #187)

## 2.6.0

### Minor Changes

- 0794f41: Add VERSION constant
- 7a3c890: Add key export support

### Patch Changes

- 4517e3b: Update version string to include package name

## 2.5.1

### Patch Changes

- Upgrade to Node v18 (#184)
- Updated dependencies
  - @turnkey/webauthn-stamper@0.4.3
  - @turnkey/api-key-stamper@0.3.1

## 2.5.0

### Minor Changes

- 464ac0e: Update protos for latest release, which includes:
  - Support optional expirations for API keys, configurable via the `expirationSeconds` parameter.
  - Support Email Auth. Details to follow ⚡️

## 2.4.2

### Patch Changes

- Updated dependencies [a03e385]
  - @turnkey/webauthn-stamper@0.4.2

## 2.4.1

### Patch Changes

- Fix universal files to stop using `require`. Use ES6 imports instead (#178)
- Updated dependencies [f87ced8]
  - @turnkey/webauthn-stamper@0.4.1

## 2.4.0

### Minor Changes

- Use rollup to build ESM and CommonJS, fix ESM support (#174)

### Patch Changes

- Updated dependencies [fc5b291]
  - @turnkey/api-key-stamper@0.3.0
  - @turnkey/webauthn-stamper@0.4.0

## 2.3.1

### Patch Changes

- Updated dependencies
  - @turnkey/api-key-stamper@0.2.0

## 2.3.0

### Minor Changes

- Sync protos from latest public endpoints

## 2.2.0

### Minor Changes

- Add ESM to package dist (#154)

### Patch Changes

- ed50a0f: simplify types

## 2.1.0

### Minor Changes

- bb6ea0b: Update generated files
  - new query endpoints to retrieve wallets (`/public/v1/query/list_wallets`)
  - new query endpoint to retrieve wallet accounts (`/public/v1/query/list_wallet_accounts`)

## 2.0.0

### Major Changes

- Synced protos from mono

### Upgrade notes

- `signRawPayload` and `signTransaction` now expect a `signWith` param instead of `privateKeyId` previously
- `signRawPayload` and `signTransaction` have been updated to expect a new type: `ACTIVITY_TYPE_SIGN_RAW_PAYLOAD_V2` and `ACTIVITY_TYPE_SIGN_TRANSACTION_V2`, respectively
- If you have policies authorizing `ACTIVITY_TYPE_SIGN_RAW_PAYLOAD` or `ACTIVITY_TYPE_SIGN_TRANSACTION` specifically, they will need to be updated to authorize `ACTIVITY_TYPE_SIGN_RAW_PAYLOAD_V2` and `ACTIVITY_TYPE_SIGN_TRANSACTION_V2` (or better yet, update your policies to allow all signing actions categorically using policy resources and actions. See https://docs.turnkey.com/managing-policies/examples)
- `createSubOrganization` now uses `ACTIVITY_TYPE_CREATE_SUB_ORGANIZATION_V4` under the hood, which utilizes wallets. The shape of the request has been updated to include the following parameter, `wallet`. Here's an example:

```js
{
  ...
  wallet: {
    walletName: "Default Wallet",
    accounts: [
      {
        curve: "CURVE_SECP256K1",
        pathFormat: "PATH_FORMAT_BIP32",
        path: "m/44'/60'/0'/0/0",
        addressFormat: "ADDRESS_FORMAT_ETHEREUM",
      },
    ],
  },
}
```

See https://docs.turnkey.com/concepts/sub-organizations for more details.

## 1.3.0

### Minor Changes

- Synced protos from mono
- Adds base URL check during initialization (closes https://github.com/tkhq/sdk/issues/124)
- The following are new features additions, fresh out the oven. Still getting them ready for primetime! Refreshed examples to come soon™️. Stay tuned and reach out to the Turnkey team if you have any questions.
  - Wallets:
    - 🟢 `ACTIVITY_TYPE_CREATE_WALLET` (via `/api/v1/submit/create_wallet`): create a HD wallet
    - 🟢 `ACTIVITY_TYPE_CREATE_WALLET_ACCOUNTS` (via `/api/v1/submit/create_wallet_accounts`): create a wallet account (address)
    - 🟢 `ACTIVITY_TYPE_SIGN_RAW_PAYLOAD_V2` (via `/api/v1/submit/sign_raw_payload_v2`): sign a payload with a specified private key or address
    - 🟢 `ACTIVITY_TYPE_SIGN_TRANSACTION_V2` (via `/api/v1/submit/sign_transaction_v2`): sign a transaction with a specified private key or address
  - Organization features:
    - 🟢 `ACTIVITY_TYPE_SET_ORGANIZATION_FEATURE` (via `/api/v1/submit/set_organization_feature`): set an organization feature
    - 🟢 `ACTIVITY_TYPE_REMOVE_ORGANIZATION_FEATURE` (via `/api/v1/submit/remove_organization_feature`): remove an organization feature
    - Only one feature supported as of this time; additional documentation to follow.
  - Export private key:
    - 🟡 `ACTIVITY_TYPE_EXPORT_PRIVATE_KEY` (via `/api/v1/submit/export_private_key`): export a private key, encrypted to a target public key. We do not yet have CLI or front-end tooling to use this safely; stay tuned!
  - Email recovery:
    - 🟡 `ACTIVITY_TYPE_INIT_USER_EMAIL_RECOVERY` (via `/api/v1/submit/init_user_email_recovery`): initialize a new email recovery flow

Note:

- 🟢: good to go!
- 🟡: these endpoints are safe to use, but still experimental/unstable. Check back for updates and guidance.

### Patch Changes

- Updated dependencies
  - @turnkey/webauthn-stamper@0.2.0

## 1.2.0

### Minor Changes

- The `createSubOrganization` request has been updated under the hood:
  - Calling `.createSubOrganization` on our HTTP client will trigger an activity of type `CREATE_SUB_ORGANIZATION_V3` instead of `CREATE_SUB_ORGANIZATION_V2` previously.
  - If there are any policies referencing `CREATE_SUB_ORGANIZATION_V2` specifically, they will no longer work out of the box if creating sub-orgs via SDK. These policies will need to be updated to allow `CREATE_SUB_ORGANIZATION_V3`. See policy examples related to access control [here](https://docs.turnkey.com/managing-policies/examples#access-control) for additional methods of constructing policies.
  - `CREATE_SUB_ORGANIZATION_V3` supports everything `CREATE_SUB_ORGANIZATION_V2` supports, with the addition of a `privateKeys` field to atomically create a sub-org with private keys. If no private keys are desired, simply provide an empty array.
  - **NOTE**: when reading `createSubOrganization` results, SDK users will now need to look at `activity.result.createSubOrganizationResultV3` instead of the previously valid `activity.result.createSubOrganizationResult`.

## 1.1.1

### Patch Changes

- Updated dependencies
  - @turnkey/api-key-stamper@0.1.1

## 1.1.0

### Minor Changes

New exports:

- new `TurnkeyClient`. This is now the preferred interface to make Turnkey requests, because it supports both API keys and webauthn-signed requests. It also doesn't rely on global initialization
- new method to poll requests: `createActivityPoller`

Deprecation notices:

- deprecate `TurnkeyApi` (use `TurnkeyClient` instead), `init`, `browserInit` (no need for them anymore if you're using `TurnkeyClient`), and `withAsyncPolling` (use `createActivityPoller` instead)
- deprecate `SignedRequest` in favor of `TSignedRequest`. Besides the more correct name, `TSignedRequest` differs in its `stamp` property. It now stores the stamper header name as well as value, so users do not have to hardcode Turnkey stamp header names (e.g. "X-Stamp-Webauthn").

Update our swagger and generated files to latest versions:

- new endpoint to update users: `/public/v1/submit/update_user`
- pagination `limit` option has been updated to `string` instead of number for consistency with other pagination options

Signing is now performed through Turnkey stampers. New dependencies:

- @turnkey/webauthn-stamper@0.1.0
- @turnkey/api-key-stamper@0.1.0

## 1.0.1

### Patch Changes

- 8d1d0e8: Synced protos from mono

## 1.0.0

### Major Changes

- 46473ec: This breaking change updates generated code to be shorter and more intuitive to read:
  - generated fetchers do not include the HTTP method in their name. For example `useGetGetActivity` is now `useGetActivity`, and `usePostSignTransaction` is `useSignTransaction`.
  - input types follow the same convention (no HTTP method in the name): `TPostCreatePrivateKeysInput` is now `TCreatePrivateKeysInput`.
  - the "federated" request helpers introduced in `0.18.0` are now named "signed" requests to better reflect what they are. `FederatedRequest` is now `SignedRequest`, and generated types follow. For example: `federatedPostCreatePrivateKeys` is now `signCreatePrivateKeys`, `federatedGetGetActivity` is now `signGetActivity`, and so on.

  The name updates should be automatically suggested if you use VSCode since the new names are simply shorter versions of the old one.

### Patch Changes

- 38b424f: Sync public api types

## 0.18.1

### Patch Changes

- Synced protos from mono

## 0.18.0

### Minor Changes

- Add support for federated requests (an example is included under `sdk/examples/with-federated-passkeys`)
- Routine re-sync protos from mono

## 0.17.1

### Patch Changes

- Re-sync protos from mono. No public-facing changes.

## 0.17.0

### Minor Changes

- Added support for ed25519
- New endpoint to programmatically approve or reject activities (`/submit/approve_activity`, `/submit/reject_activity`)
- New endpoint to programmatically create authenticators (`/submit/create_authenticators`)
- New endpoints to update Private Key tags (`/submit/update_private_key_tag`)
- New endpoints to update User tags (`/submit/update_user_tag`)
- Simplified shape for `AuthenticatorParams` with a new `AuthenticatorParamsV2`. To take advantage of this new shape, use `ACTIVITY_TYPE_CREATE_USERS_V2` and the new `ACTIVITY_TYPE_CREATE_AUTHENTICATORS`.

## 0.16.0

### Minor Changes

- Fix `.postGetPrivateKey(...)`'s underlying path, while adding `@deprecated` `.postGetPrivateKeyBackwardsCompat(...)` for backward compatibility

## 0.15.0

### Minor Changes

- Export a new helper for offline request signing: `sealAndStampRequestBody(...)`.

## 0.14.0

### Minor Changes

- Updated the `addressFormats` enum field in `/submit/create_private_keys`

## 0.13.2

### Patch Changes

- New `TurnkeyRequestError` error class that contains rich error details

## 0.13.1

### Patch Changes

- Error messages now contain Turnkey-specific error details

## 0.13.0

### Minor Changes

- New `/submit/create_api_only_users` endpoint: `TurnkeyApi.postCreateApiOnlyUsers(...)`
- Marked `TurnkeyApi.postCreateUsers(...)` as deprecated
- Improved documentation on methods (via TSDoc)

## 0.12.0

### Minor Changes

- Error messages now contain Turnkey-specific error code and message

## 0.11.0

### Minor Changes

- New `/submit/create_users` endpoint: `TurnkeyApi.postCreateUsers(...)`

## 0.10.0

### Minor Changes

- No public-facing changes

## 0.9.0

### Minor Changes

- Improved support for React Native runtime (https://github.com/tkhq/sdk/pull/37)

## 0.8.1

### Patch Changes

- Switched from `undici` to `cross-fetch` to improve bundler compatibility

## 0.8.0

### Minor Changes

- Added browser runtime support — `@turnkey/http` is now a universal (isomorphic) package
- The API fetchers are now exported as namespace `TurnkeyApi`. `PublicApiService` has been marked as deprecated, but will remain functional until we hit v1.0.
- Dropped support for Node.js v14; we recommend using Node v18+

## 0.7.0

### Minor Changes

- Improved documentation
- Added `withAsyncPolling(...)` helper to provide built-in async polling support. Read more:
  - https://github.com/tkhq/sdk/tree/main/packages/http#withasyncpolling-helper

## 0.6.0

### Minor Changes

- Improved OpenAPI documentation

## 0.5.0

### Minor Changes

- Arbitrary message signing

## 0.4.0

### Minor Changes

- `timestamp` -> `timestampMs`

## 0.3.1

### Patch Changes

- Fix outdated artifact

## 0.3.0

### Minor Changes

- `keyId` -> `privateKeyId` everywhere

## 0.2.0

### Minor Changes

- Change parameter from `keyId` to `privateKeyId`
- Bump API version to latest Beta

## 0.1.3

### Patch Changes

- Support runtime config for credentials

## 0.1.2

### Patch Changes

- Drop internal dev dependency

## 0.1.1

### Patch Changes

- Initial release
- Updated dependencies
  - @turnkey/jest-config@0.1.1
