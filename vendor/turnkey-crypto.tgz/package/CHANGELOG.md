# @turnkey/crypto

## 2.12.0

### Minor Changes

- [#1497](https://github.com/tkhq/sdk/pull/1497) [`3af9589`](https://github.com/tkhq/sdk/commit/3af958959c2827d3404525fd22d73be5e306111c) Author [@emostov](https://github.com/emostov) - Add `computeActivityFingerprint` to `@turnkey/crypto`, deriving the `sha256:<hex>` activity fingerprint from a request body. `createExportSecretsProposal` now uses it instead of building the string inline.

- [#1479](https://github.com/tkhq/sdk/pull/1479) [`35f9cce`](https://github.com/tkhq/sdk/commit/35f9cce418b3704d8e77840c0d76b325079982cb) Author [@emostov](https://github.com/emostov) - Add Secrets API support: `importSecret`, `exportSecret`, `getSecrets`, and the multi-party export proposal API (`createExportSecretsProposal`, `submitExportSecrets`, `awaitExportedSecrets`) on the server client, plus `encryptSecretToBundle` and `decryptSecretBundle` crypto helpers

### Patch Changes

- Updated dependencies [[`35f9cce`](https://github.com/tkhq/sdk/commit/35f9cce418b3704d8e77840c0d76b325079982cb), [`22a6682`](https://github.com/tkhq/sdk/commit/22a6682a3a7c5ad7b192cb46ffc599e073802ccf)]:
  - @turnkey/sdk-types@1.6.0

## 2.11.3

### Patch Changes

- Updated dependencies [[`e1fdcb1`](https://github.com/tkhq/sdk/commit/e1fdcb16444e6902f220612bea002a7313607900)]:
  - @turnkey/sdk-types@1.5.1

## 2.11.2

### Patch Changes

- Updated dependencies [[`f191ad9`](https://github.com/tkhq/sdk/commit/f191ad98d5bd194a12045d9b0c562abccb07169a)]:
  - @turnkey/sdk-types@1.5.0

## 2.11.1

### Patch Changes

- Updated dependencies [[`4a20057`](https://github.com/tkhq/sdk/commit/4a20057b37d6081c0c38c0a4840affcd16140d47)]:
  - @turnkey/sdk-types@1.4.0

## 2.11.0

### Minor Changes

- [#1191](https://github.com/tkhq/sdk/pull/1191) [`c9a13f6`](https://github.com/tkhq/sdk/commit/c9a13f65092e9a7cddc0716206331db9a8b614d2) Thanks [@t-vila](https://github.com/t-vila)! - Add `verifyOtpVerificationToken`: verifies an OTP verification token JWT's ES256 signature, required claims, and expiry.

### Patch Changes

- Updated dependencies [[`09d0e19`](https://github.com/tkhq/sdk/commit/09d0e19ee6b4b2c1be14762650613f7fbae036b0), [`b447497`](https://github.com/tkhq/sdk/commit/b447497e965b0b1df02d2294e87f89cedb761719)]:
  - @turnkey/sdk-types@1.3.0

## 2.10.1

### Patch Changes

- Updated dependencies [[`cd1af93`](https://github.com/tkhq/sdk/commit/cd1af93c41a3f41c3c68589cfa6cfe17c1812c2f)]:
  - @turnkey/sdk-types@1.2.0

## 2.10.0

### Minor Changes

- [#1314](https://github.com/tkhq/sdk/pull/1314) [`ad044cd`](https://github.com/tkhq/sdk/commit/ad044cdcd41690c6479a81c56ebcd6d5108581fb) Author [@taylorjdawson](https://github.com/taylorjdawson) - Add a helper for verifying Turnkey webhook signatures.

### Patch Changes

- Updated dependencies [[`bf2c28f`](https://github.com/tkhq/sdk/commit/bf2c28fec690ec31254125405bf15a482139109b), [`f505818`](https://github.com/tkhq/sdk/commit/f505818e121c137d290156a32918a884ba80e5f5)]:
  - @turnkey/sdk-types@1.1.0

## 2.9.0

### Minor Changes

- [#1250](https://github.com/tkhq/sdk/pull/1250) [`d677115`](https://github.com/tkhq/sdk/commit/d677115e60aaee53319131723541211457803317) Author [@moeodeh3](https://github.com/moeodeh3) - - Export `PRODUCTION_TLS_FETCHER_SIGN_PUBLIC_KEY` constant
  - Add `encryptOtpCodeToBundle()` helper that encrypts an OTP code and client public key to the enclave's target key using HPKE

### Patch Changes

- Updated dependencies [[`34522d4`](https://github.com/tkhq/sdk/commit/34522d447592138a82d34cd690091315f9748edb), [`7a36539`](https://github.com/tkhq/sdk/commit/7a36539196856a8bd4ca4c54115fa9874ccc83fa), [`47c0ca4`](https://github.com/tkhq/sdk/commit/47c0ca4696c8a518f95550c35cfe4cb4985a2633), [`5624d54`](https://github.com/tkhq/sdk/commit/5624d5417d2cc30032ca4ce71da0a5c7ab9a462d), [`6128132`](https://github.com/tkhq/sdk/commit/6128132d910f658cdf83ecc1dec6598eb20c008a), [`7b80b1e`](https://github.com/tkhq/sdk/commit/7b80b1e9755b83988b5e49c34dff13dd92d9932f)]:
  - @turnkey/sdk-types@1.0.0

## 2.8.14

### Patch Changes

- Updated dependencies [[`ef66673`](https://github.com/tkhq/sdk/commit/ef6667325d210c8aa0ea4c1d11d834ff28ddb66c), [`8209887`](https://github.com/tkhq/sdk/commit/8209887d48bae7ea617645603a156aeb1cfbd2e7)]:
  - @turnkey/sdk-types@0.14.0

## 2.8.13

### Patch Changes

- Updated dependencies [[`068abcb`](https://github.com/tkhq/sdk/commit/068abcb11e05972329034222bed52865f405f1c4)]:
  - @turnkey/sdk-types@0.13.0

## 2.8.12

### Patch Changes

- Updated dependencies [[`dfdd864`](https://github.com/tkhq/sdk/commit/dfdd8647266fdd0297aaea32046ee815ae8fc27c)]:
  - @turnkey/sdk-types@0.12.1

## 2.8.11

### Patch Changes

- Updated dependencies [[`1f6e240`](https://github.com/tkhq/sdk/commit/1f6e2403fca1fd9cbca646f88c88dbc49ddb0c34), [`58e04e5`](https://github.com/tkhq/sdk/commit/58e04e5856626d9d2593abb61d8ca32d8ccbb833), [`7458b7c`](https://github.com/tkhq/sdk/commit/7458b7cd6fc64796b376e3374b7c2ed79467459c)]:
  - @turnkey/sdk-types@0.12.0

## 2.8.10

### Patch Changes

- Updated dependencies [[`8e075b7`](https://github.com/tkhq/sdk/commit/8e075b7161ccc68cb446b10b54737856fa0c6d31)]:
  - @turnkey/sdk-types@0.11.2

## 2.8.9

### Patch Changes

- [#1165](https://github.com/tkhq/sdk/pull/1165) [`d0dba04`](https://github.com/tkhq/sdk/commit/d0dba0412fa7b0c7c9b135e73cc0ef6f55187314) Author [@moeodeh3](https://github.com/moeodeh3) - Remove `@turnkey/http` and `@turnkey/api-key-stamper` from devDependencies

- Updated dependencies [[`91d6a9e`](https://github.com/tkhq/sdk/commit/91d6a9eb1b9ac9e21745749615ac7a7be66f5cf6)]:
  - @turnkey/sdk-types@0.11.1

## 2.8.8

### Patch Changes

- Updated dependencies [[`78ec1d9`](https://github.com/tkhq/sdk/commit/78ec1d9afcafde3ca7107fc720323d486d6afaea)]:
  - @turnkey/sdk-types@0.11.0

## 2.8.7

### Patch Changes

- Updated dependencies [[`29a42db`](https://github.com/tkhq/sdk/commit/29a42db8f5f3ef8b9c23c90cd00f4c21027aac2e)]:
  - @turnkey/sdk-types@0.10.0

## 2.8.6

### Patch Changes

- Updated dependencies [[`80ea306`](https://github.com/tkhq/sdk/commit/80ea306025a2161ff575a5e2b45794460eafdf1b)]:
  - @turnkey/sdk-types@0.9.0

## 2.8.5

### Patch Changes

- [#1068](https://github.com/tkhq/sdk/pull/1068) [`5f829c6`](https://github.com/tkhq/sdk/commit/5f829c67af03bb85c3806acd202b2debf8274e78) Author [@moeodeh3](https://github.com/moeodeh3) - - Updated dependencies [[`9fbd5c4`](https://github.com/tkhq/sdk/commit/9fbd5c459782dc3721dd0935d0a4458babce258b):
  - @turnkey/sdk-types@0.7.0
- Updated dependencies [[`084acce`](https://github.com/tkhq/sdk/commit/084acce85fe7c15513a025e77c1571012ac82e4b), [`67b03a5`](https://github.com/tkhq/sdk/commit/67b03a5d9ab1b6eabfb0b41938ac91365b5dcd9b)]:
  - @turnkey/sdk-types@0.8.0

## 2.8.4

### Patch Changes

- [#1050](https://github.com/tkhq/sdk/pull/1050) [`c745646`](https://github.com/tkhq/sdk/commit/c745646ae4b2a275e116abca07c6e108f89beb04) Author [@amircheikh](https://github.com/amircheikh) - - Removed `@peculiar/webcrypto` dependancy. This will fix build errors in environments where `webcrypto` is not defined but will still require a polyfill if you use a function where `webcrypto` is required.

## 2.8.3

### Patch Changes

- [#992](https://github.com/tkhq/sdk/pull/992) [`5c4495b`](https://github.com/tkhq/sdk/commit/5c4495bff1b0abfe3c427ead1b8e1a8d510c8186) Author [@amircheikh](https://github.com/amircheikh) - - `verify` function is now exposed and supports web platforms

- Updated dependencies [[`5c4495b`](https://github.com/tkhq/sdk/commit/5c4495bff1b0abfe3c427ead1b8e1a8d510c8186)]:
  - @turnkey/sdk-types@0.6.3

## 2.8.2

### Patch Changes

- Updated dependencies [[`9df42ad`](https://github.com/tkhq/sdk/commit/9df42adc02c7ff77afba3b938536e79b57882ef1)]:
  - @turnkey/sdk-types@0.6.2

## 2.8.1

### Patch Changes

- Updated dependencies [[`68631c4`](https://github.com/tkhq/sdk/commit/68631c4008387f845dfe4f1a139981011727f6c9)]:
  - @turnkey/sdk-types@0.6.1

## 2.8.0

### Minor Changes

- [#974](https://github.com/tkhq/sdk/pull/974) [`3997c0f`](https://github.com/tkhq/sdk/commit/3997c0fd08a8a85108acf904c0bf39d69f8dc79c) Author [@narimonf](https://github.com/narimonf) - Added verification tooling for app proofs and boot proofs. Primarily adds `verify()`, which verifies an app proof boot proof pair.

### Patch Changes

- Updated dependencies [[`3997c0f`](https://github.com/tkhq/sdk/commit/3997c0fd08a8a85108acf904c0bf39d69f8dc79c)]:
  - @turnkey/sdk-types@0.6.0

## 2.7.0

### Minor Changes

- [#947](https://github.com/tkhq/sdk/pull/947) [`2191a1b`](https://github.com/tkhq/sdk/commit/2191a1b201fb17dea4c79cf9e02b3a493b18f97a) Author [@amircheikh](https://github.com/amircheikh) - - Added `encryptOnRampSecret` helper function. This is used for encrypting your fiat on ramp secrets before passing into the `CreateFiatOnRampCredential` activity

## 2.6.0

### Minor Changes

- Updated dependencies [[`fc1d6e2`](https://github.com/tkhq/sdk/commit/fc1d6e2d26f4a53116633e9e8cccccd792267f4e), [`fc1d6e2`](https://github.com/tkhq/sdk/commit/fc1d6e2d26f4a53116633e9e8cccccd792267f4e), [`4880f26`](https://github.com/tkhq/sdk/commit/4880f26a4dd324c049bff7f35284098ccfc55823), [`c6ee323`](https://github.com/tkhq/sdk/commit/c6ee3239c389a7bbbbb23610c84b883ed298f95c), [`c6ee323`](https://github.com/tkhq/sdk/commit/c6ee3239c389a7bbbbb23610c84b883ed298f95c), [`c6ee323`](https://github.com/tkhq/sdk/commit/c6ee3239c389a7bbbbb23610c84b883ed298f95c), [`06347ad`](https://github.com/tkhq/sdk/commit/06347adfa08fb0867c350e43821d0fed06c49624), [`6bfcbc5`](https://github.com/tkhq/sdk/commit/6bfcbc5c098e64ab1d115518733b87cfc1653e17)]:
  - @turnkey/encoding@0.6.0

## 2.6.0-beta.6

### Minor Changes

- @turnkey/react-wallet-kit and @turnkey/core beta release

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.6

## 2.6.0-beta.5

### Minor Changes

- SDK beta release @turnkey/react-wallet-kit @turnkey/core

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.5

## 2.6.0

### Minor Changes

- [#840](https://github.com/tkhq/sdk/pull/840) [`d7420e6`](https://github.com/tkhq/sdk/commit/d7420e6c3559efc1024b58749b31d253150cb189) Author [@zkharit](https://github.com/zkharit) - This change adds a new encryption mechanism to allow for messages to be encrypted to an enclaves quorum public key. A helper function specifically for OAith 2.0 client secret encryption is also included

## 2.5.1-beta.4

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.4

## 2.5.1-beta.3

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.3

## 2.5.1-beta.2

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.2

## 2.5.1-beta.1

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.1

## 2.5.1-beta.0

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.0

## 2.5.0

### Minor Changes

- [#812](https://github.com/tkhq/sdk/pull/812) [`6cde41c`](https://github.com/tkhq/sdk/commit/6cde41cfecdfb7d54abf52cc65e28ef0e2ad6ba3) Author [@turnekybc](https://github.com/turnekybc) - Add `@turnkey/encoding` as a package dependency instead of a devDependency to `@turnkey/crypto`. This resolves an issue with transitive dependencies when devDependencies are not included in the artifact.

## 2.4.3

### Patch Changes

- [#720](https://github.com/tkhq/sdk/pull/720) [`6cbff7a`](https://github.com/tkhq/sdk/commit/6cbff7a0c0b3a9a05586399e5cef476154d3bdca) Author [@moeodeh3](https://github.com/moeodeh3) - Fixed `decryptExportBundle` not working in some environments by adding a shim to handle `bs58`'s ESM-only export.

## 2.4.2

### Patch Changes

- [#699](https://github.com/tkhq/sdk/pull/699) [`c5cdf82`](https://github.com/tkhq/sdk/commit/c5cdf8229da5da1bd6d52db06b2fe42826e96d57) Author [@andrewkmin](https://github.com/andrewkmin) - Add validations to `fromDerSignature` for parsing DER signatures in the Turnkey context

- [#716](https://github.com/tkhq/sdk/pull/716) [`fa46701`](https://github.com/tkhq/sdk/commit/fa467019eef34b5199372248edff1e7a64934e79) Author [@moeodeh3](https://github.com/moeodeh3) - Fixed `decryptCredentialBundle` not working in React Native by adding a shim to handle `bs58check`'s ESM-only export.

## 2.4.1

### Patch Changes

- [#700](https://github.com/tkhq/sdk/pull/700) [`878e039`](https://github.com/tkhq/sdk/commit/878e03973856cfec83e6e3fda5b76d1b64943628) Author [@andrewkmin](https://github.com/andrewkmin) - Add validations to uncompressRawPublicKey method

## 2.4.0

### Minor Changes

- [#662](https://github.com/tkhq/sdk/pull/662) [`10ee5c5`](https://github.com/tkhq/sdk/commit/10ee5c524b477ce998e4fc635152cd101ae5a9cc) Thanks [@moe-dev](https://github.com/moe-dev)! - Add function `verifySessionJwtSignature` to verify session tokens return from Turnkey and signed by the notarizer

## 2.3.1

### Patch Changes

- 2bc0046: Migrated from WebCrypto (crypto.subtle.verify) to Noble for ECDSA signature verification

## 2.3.0

### Minor Changes

- 668edfa: Add keyformat to decryptExportBundle for displaying Solana private keys

## 2.2.0

### Minor Changes

- Added `toDerSignature` function used to convert a raw ECDSA signature into DER-encoded format for compatibility with our backend, which requires DER signatures

## 2.1.0

### Minor Changes

- https://github.com/tkhq/sdk/pull/384: Reorganize into two subparts:
  - `crypto.ts`: core cryptography utilities
  - `turnkey.ts`: Turnkey-specific cryptography utilities

  Add `verifyStampSignature` method:
  - See in-line code docs for more details + example of usage
  - This is useful for checking the validity of a stamp (signature) against the request body

### Patch Changes

- d989d46: Remove unnecessary react/typsecript packages

## 2.0.0

### Major Changes

- [BREAKING CHANGE] renamed `decryptBundle` to `decryptCredentialBundle` (for decrypting email auth/recovery and oauth credential bundles) in order to distinguish from the new `decryptExportBundle` (for decrypting bundles containing wallet mnemonics or private key material)

### Patch Changes

- Updated dependencies [e5c4fe9]
  - @turnkey/encoding@0.4.0

## 1.0.0

### Major Changes

- 93666ff: turnkey/crypto standard HPKE encryption, first major release. Allows for programmatic importing in environments like node. Moved some encoding helper functions to turnkey/encoding

### Patch Changes

- Updated dependencies [93666ff]
  - @turnkey/encoding@0.3.0

## 0.2.1

### Patch Changes

- Updated dependencies
  - @turnkey/encoding@0.2.1

## 0.2.0

### Minor Changes

- Add HPKE encryption

## 0.1.1

### Patch Changes

- d968e0b: Bugfix: return public key

## 0.1.0

Initial release
