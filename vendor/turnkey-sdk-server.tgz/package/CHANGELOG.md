# @turnkey/sdk-server

## 8.3.0

### Minor Changes

- [#1479](https://github.com/tkhq/sdk/pull/1479) [`35f9cce`](https://github.com/tkhq/sdk/commit/35f9cce418b3704d8e77840c0d76b325079982cb) Author [@emostov](https://github.com/emostov) - Add Secrets API support: `importSecret`, `exportSecret`, `getSecrets`, and the multi-party export proposal API (`createExportSecretsProposal`, `submitExportSecrets`, `awaitExportedSecrets`) on the server client, plus `encryptSecretToBundle` and `decryptSecretBundle` crypto helpers

- [#1458](https://github.com/tkhq/sdk/pull/1458) [`22a6682`](https://github.com/tkhq/sdk/commit/22a6682a3a7c5ad7b192cb46ffc599e073802ccf) Author [@besler613](https://github.com/besler613) - Sync transaction history API types with the latest public API swagger.

  ### Transaction history query endpoints
  - `listEthTransactionHistory` (`POST /public/v1/query/list_eth_transaction_history`) — paginated EVM transaction history for a wallet or private-key address on a supported CAIP-2 chain.
  - `listSolTransactionHistory` (`POST /public/v1/query/list_sol_transaction_history`) — paginated Solana transaction history for a wallet or private-key address on a supported CAIP-2 chain.

  ### Pagination type update

  Transaction history pagination now uses the shared `v1Pagination` / `v1PageInfo` types instead of transaction-history-specific `v1TransactionHistoryPaginationOptions` / `v1TransactionHistoryPaginationCursors`.

  **Before:**

  ```ts
  const response = await client.listEthTransactionHistory({ ... });
  const after = response.paginationCursors.after;
  ```

  **After:**

  ```ts
  const response = await client.listEthTransactionHistory({ ... });
  const after = response.pageInfo?.endCursor;
  ```

  These surfaces are generated into `@turnkey/http`, `@turnkey/sdk-types`, `@turnkey/sdk-browser`, `@turnkey/sdk-server`, and `@turnkey/core`.

### Patch Changes

- [#1497](https://github.com/tkhq/sdk/pull/1497) [`3af9589`](https://github.com/tkhq/sdk/commit/3af958959c2827d3404525fd22d73be5e306111c) Author [@emostov](https://github.com/emostov) - Add `computeActivityFingerprint` to `@turnkey/crypto`, deriving the `sha256:<hex>` activity fingerprint from a request body. `createExportSecretsProposal` now uses it instead of building the string inline.

- Updated dependencies [[`3af9589`](https://github.com/tkhq/sdk/commit/3af958959c2827d3404525fd22d73be5e306111c), [`35f9cce`](https://github.com/tkhq/sdk/commit/35f9cce418b3704d8e77840c0d76b325079982cb), [`22a6682`](https://github.com/tkhq/sdk/commit/22a6682a3a7c5ad7b192cb46ffc599e073802ccf)]:
  - @turnkey/crypto@2.12.0
  - @turnkey/sdk-types@1.6.0
  - @turnkey/http@6.3.0
  - @turnkey/api-key-stamper@0.6.13
  - @turnkey/wallet-stamper@1.1.25

## 8.2.1

### Patch Changes

- Updated dependencies [[`e1fdcb1`](https://github.com/tkhq/sdk/commit/e1fdcb16444e6902f220612bea002a7313607900)]:
  - @turnkey/sdk-types@1.5.1
  - @turnkey/api-key-stamper@0.6.12
  - @turnkey/wallet-stamper@1.1.24
  - @turnkey/http@6.2.1

## 8.2.0

### Minor Changes

- [#1480](https://github.com/tkhq/sdk/pull/1480) [`f191ad9`](https://github.com/tkhq/sdk/commit/f191ad98d5bd194a12045d9b0c562abccb07169a) Thanks [@moe-dev](https://github.com/moe-dev)! - Expose `createSwapQuote` (`ACTIVITY_TYPE_CREATE_SWAP_QUOTE`) and `executeSwap` (`ACTIVITY_TYPE_EXECUTE_SWAP_V2`) on the high-level SDK clients. `createSwapQuote` takes `signWith`, CAIP-19 tokens, amount, and optional `slippageBps`, and returns provider quotes. `executeSwap` is quote-bound: pass `quoteId` plus the exact quoted amounts (`quotedOutputAmount`, `minOutputAmount`, `sponsor`); the signer is derived from the quote. Poll with `getSwapStatus` using the returned `swapRequestId`.

  Also align transaction-history list responses with standard pagination (`v1Pagination` / `pageInfo`) instead of the previous transaction-history-specific cursor types.

### Patch Changes

- Updated dependencies [[`f191ad9`](https://github.com/tkhq/sdk/commit/f191ad98d5bd194a12045d9b0c562abccb07169a)]:
  - @turnkey/sdk-types@1.5.0
  - @turnkey/http@6.2.0
  - @turnkey/wallet-stamper@1.1.23
  - @turnkey/api-key-stamper@0.6.11

## 8.1.0

### Minor Changes

- [#1475](https://github.com/tkhq/sdk/pull/1475) [`4a20057`](https://github.com/tkhq/sdk/commit/4a20057b37d6081c0c38c0a4840affcd16140d47) Thanks [@moe-dev](https://github.com/moe-dev)! - Sync generated API clients and types with the latest public API swagger.

  ### New query endpoints
  - `getClaimEarnFeesStatus` (`POST /public/v1/query/get_claim_earn_fees_status`) — poll Earn fee-claim status by the `claimRequestId` returned from `ClaimEarnFees`. Response status is `PENDING` | `COMPLETED` | `FAILED`, with optional `claimTxHash` / `error`.
  - `getSwapStatus` (`POST /public/v1/query/get_swap_status`) — poll swap status by the `swapRequestId` returned from `ExecuteSwap`. Covers same-chain and cross-chain swaps, and returns provider, input/output tokens and amounts, origin/destination tx hashes, optional refund info on failure, and normalized error details.

  ### New submit endpoints / activities
  - `claimSwapFees` (`POST /public/v1/submit/claim_swap_fees`, `ACTIVITY_TYPE_CLAIM_SWAP_FEES`) — claim swap fees through the activity pipeline; result includes a Relay `requestId`.
  - `ethUndelegate7702` (`POST /public/v1/submit/eth_undelegate_7702`, `ACTIVITY_TYPE_ETH_UNDELEGATE_7702`) — submit an EIP-7702 undelegation for a wallet/private-key address on a supported CAIP-2 chain. Optional nonce / gas / fee fields; result returns a `sendTransactionStatusId` for polling.
  - `upsertSwapConfig` (`POST /public/v1/submit/upsert_swap_config`, `ACTIVITY_TYPE_UPSERT_SWAP_CONFIG`) — enable or update org swap config (`feeReceiverWalletAddress`, `feeBps`, and Enterprise-only `stableFeeBps` for stablecoin pairs).
  - `createSwapQuote` (`ACTIVITY_TYPE_CREATE_SWAP_QUOTE`) — request provider quotes for a swap (`signWith`, CAIP-19 `inputToken` / `outputToken`, `inputAmount`, optional `slippageBps`). Returns one or more `v1SwapQuote` values; pass `quoteId` into execute-swap v2.

  ### Related activity / type updates
  - `ACTIVITY_TYPE_EXECUTE_SWAP_V2` / `v1ExecuteSwapIntentV2` — quote-bound swap execution. Takes `quoteId` plus the exact quoted amounts (`inputAmount`, `quotedOutputAmount`, `minOutputAmount`, `sponsor`), with optional `evmNonce` / `recentBlockhash` / `gasStationNonce`. Signer is derived from the quote and must not be resupplied. Result still exposes `swapRequestId` for `getSwapStatus`.
  - `ACTIVITY_TYPE_UPDATE_WALLET_ACCOUNT_NAME` / `v1UpdateWalletAccountNameIntent` — rename a wallet account by `walletAccountId`.
  - Supporting swap types: `v1SwapQuote`, `v1SwapError`, `v1SwapRefund`.
  - CAIP-2 enums used by transaction intents (including undelegation) now include `eip155:143`.

  These surfaces are generated into `@turnkey/http`, `@turnkey/sdk-types`, `@turnkey/sdk-browser`, `@turnkey/sdk-server`, and `@turnkey/core`.

### Patch Changes

- Updated dependencies [[`4a20057`](https://github.com/tkhq/sdk/commit/4a20057b37d6081c0c38c0a4840affcd16140d47)]:
  - @turnkey/sdk-types@1.4.0
  - @turnkey/http@6.1.0
  - @turnkey/wallet-stamper@1.1.22
  - @turnkey/api-key-stamper@0.6.10

## 8.0.0

### Major Changes

- [#1448](https://github.com/tkhq/sdk/pull/1448) [`de5e169`](https://github.com/tkhq/sdk/commit/de5e1692ab79c18d898326e76777fa7ea54df812) Thanks [@Bijan-Massoumi](https://github.com/Bijan-Massoumi)! - Add Solana send-transaction v2 support for transactions requiring multiple Turnkey signers.

  `solSendTransaction()` now uses `ACTIVITY_TYPE_SOL_SEND_TRANSACTION_V2`. The v2 intent accepts an ordered `signWiths` array for transactions requiring multiple Turnkey signers, and its full unsigned transaction wire format is hex-encoded.

  **Before:**

  ```ts
  await client.solSendTransaction({
    unsignedTransaction: unsignedTransactionBase64,
    signWith: signerAddress,
    caip2,
    sponsor,
  });
  ```

  **After:**

  ```ts
  await client.solSendTransaction({
    unsignedTransaction: unsignedTransactionHex,
    signWiths: [signerAddress],
    caip2,
    sponsor,
  });
  ```

### Minor Changes

- [#1452](https://github.com/tkhq/sdk/pull/1452) [`b447497`](https://github.com/tkhq/sdk/commit/b447497e965b0b1df02d2294e87f89cedb761719) Author [@ericvelazquez](https://github.com/ericvelazquez) - Add Turnkey Earn APIs (early access) to the high-level SDK clients: `earnVaults`, `earnEnabledVaults`, `earnPositions`, `earnDeposit`, `earnDepositStatus`, `earnWithdraw`, `earnWithdrawStatus`, `earnDeployWrapper`, and `earnDeployStatus`.

  The Earn read endpoints live under `/query/` but aren't named `get`/`list`/`test`/`validate`, so each package's codegen pins `/query/earn_*` to query methods by path. `@turnkey/http` gains the previously-missing `earnDeployStatus` so its generated Earn surface matches the other packages.

### Patch Changes

- Updated dependencies [[`09d0e19`](https://github.com/tkhq/sdk/commit/09d0e19ee6b4b2c1be14762650613f7fbae036b0), [`de5e169`](https://github.com/tkhq/sdk/commit/de5e1692ab79c18d898326e76777fa7ea54df812), [`b447497`](https://github.com/tkhq/sdk/commit/b447497e965b0b1df02d2294e87f89cedb761719)]:
  - @turnkey/sdk-types@1.3.0
  - @turnkey/http@6.0.0
  - @turnkey/wallet-stamper@1.1.21
  - @turnkey/api-key-stamper@0.6.9

## 7.0.0

### Major Changes

- [#1433](https://github.com/tkhq/sdk/pull/1433) [`cd1af93`](https://github.com/tkhq/sdk/commit/cd1af93c41a3f41c3c68589cfa6cfe17c1812c2f) Author [@amircheikh](https://github.com/amircheikh) - - Synced with Mono v2026.7.3
  - `EthSendTransaction()` function call now uses `ACTIVITY_TYPE_ETH_SEND_TRANSACTION_V2`. This activity allows for multiple eth calls to be batched together via the new `calls` array. This means the intent for the activity has now changed.

  **Before:**

  ```ts
  await client.ethSendTransaction({
    from,
    caip2,
    to,
    value,
    data,
  });
  ```

  **After:**

  ```ts
  await client.ethSendTransaction({
    from,
    caip2,
    calls: [{ to, value, data }],
  });
  ```

### Patch Changes

- Updated dependencies [[`cd1af93`](https://github.com/tkhq/sdk/commit/cd1af93c41a3f41c3c68589cfa6cfe17c1812c2f), [`cd1af93`](https://github.com/tkhq/sdk/commit/cd1af93c41a3f41c3c68589cfa6cfe17c1812c2f)]:
  - @turnkey/http@5.0.0
  - @turnkey/sdk-types@1.2.0
  - @turnkey/wallet-stamper@1.1.20
  - @turnkey/api-key-stamper@0.6.8

## 6.1.1

### Patch Changes

- Updated dependencies [[`325fded`](https://github.com/tkhq/sdk/commit/325fdedf2c647c9a93f28aa7355b1ff0053689f9)]:
  - @turnkey/http@4.1.1
  - @turnkey/wallet-stamper@1.1.19

## 6.1.0

### Minor Changes

- [#1324](https://github.com/tkhq/sdk/pull/1324) [`f505818`](https://github.com/tkhq/sdk/commit/f505818e121c137d290156a32918a884ba80e5f5) Author [@janjakubnanista](https://github.com/janjakubnanista) - ### Breaking/Behavioral Changes

  #### `nonce` parameter in `oauth2Authenticate` is now required

  ```ts
  # Before
  apiClient.oauth2Authenticate({
    oauth2CredentialId: ...,
    authCode: ...,
    redirectUri: ...,
    codeVerifier: ...,
    bearerTokenTargetPublicKey: ...,
    // nonce can be undefined
    nonce: undefined
  })

  # After
  apiClient.oauth2Authenticate({
    oauth2CredentialId: ...,
    authCode: ...,
    redirectUri: ...,
    codeVerifier: ...,
    bearerTokenTargetPublicKey: ...,
    // nonce is required
    nonce: ""
  })
  ```

  #### Solana transactions in Transaction Management are now limited to the following `caip2` values:
  - `solana:mainnet`
  - `solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp`
  - `solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d`
  - `solana:devnet`
  - `solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1`
  - `solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1wcaWoxPkrZBG`

  ### New SDK methods

  #### TVC

  These methods will only work if you are part of the [TVC beta](https://www.turnkey.com/turnkey-verifiable-cloud#waitlist)
  - `getTvcApp`
  - `getTvcDeployment`
  - `getTvcAppDeployments`
  - `getTvcApps`
  - `validateTvcImage`
  - `createTvcApp`
  - `createTvcDeployment`
  - `createTvcManifestApprovals`
  - `deleteTvcAppAndDeployments`
  - `deleteTvcDeployment`
  - `restoreTvcDeployment`
  - `updateTvcAppLiveDeployment`

  #### Spark protocol support
  - `sparkClaimTransfer`
  - `sparkPrepareLightningReceive`
  - `sparkPrepareTransfer`
  - `sparkSignFrost`

### Patch Changes

- Updated dependencies [[`bf2c28f`](https://github.com/tkhq/sdk/commit/bf2c28fec690ec31254125405bf15a482139109b), [`f505818`](https://github.com/tkhq/sdk/commit/f505818e121c137d290156a32918a884ba80e5f5)]:
  - @turnkey/sdk-types@1.1.0
  - @turnkey/http@4.1.0
  - @turnkey/wallet-stamper@1.1.18
  - @turnkey/api-key-stamper@0.6.7

## 6.0.0

### Major Changes

- [#1225](https://github.com/tkhq/sdk/pull/1225) [`f39e11e`](https://github.com/tkhq/sdk/commit/f39e11eb4dc6dde19516c3f28263528e424672f1) Author [@ethankonk](https://github.com/ethankonk) - Now uses `@turnkey/sdk-types` for endpoint and helper function types

- [#1250](https://github.com/tkhq/sdk/pull/1250) [`654fadc`](https://github.com/tkhq/sdk/commit/654fadc7b8296b7af7e5a68dee9ee6de20eef4c1) Author [@moeodeh3](https://github.com/moeodeh3) - > ⚠️ **Policy warning:** `@turnkey/sdk-server` authenticates with an API key pair (public + private key from env). These changes introduce new activity types (`ACTIVITY_TYPE_INIT_OTP_V3`, `ACTIVITY_TYPE_VERIFY_OTP_V2`, `ACTIVITY_TYPE_OTP_LOGIN_V2`, `ACTIVITY_TYPE_CREATE_SUB_ORGANIZATION_V8`, `ACTIVITY_TYPE_CREATE_OAUTH_PROVIDERS_V2`). If your policies target specific activity types, you must update them to allow the new versions. Generic resource/action policies are unaffected.

  > **Specific policy (must update):**
  >
  > ```json
  > {
  >   "policyName": "Allow user <USER_ID> to init OTP",
  >   "effect": "EFFECT_ALLOW",
  >   "consensus": "approvers.any(user, user.id == '<YOUR_API_USER_ID>')",
  >   "condition": "activity.type == 'ACTIVITY_TYPE_INIT_OTP_V2'"
  > }
  > ```
  >
  > ↑ Either update `ACTIVITY_TYPE_INIT_OTP_V2` → `ACTIVITY_TYPE_INIT_OTP_V3` (and similarly for the other activities), or switch to a generic resource/action policy to future-proof against version bumps.
  >
  > **Generic policy (no change needed):**
  >
  > ```json
  > {
  >   "policyName": "Allow user <USER_ID> to initiate and verify OTP activities",
  >   "effect": "EFFECT_ALLOW",
  >   "consensus": "approvers.any(user, user.id == '<YOUR_API_USER_ID>')",
  >   "condition": "activity.resource in ['AUTH', 'OTP'] && activity.action in ['CREATE','VERIFY']"
  > }
  > ```

  ### `sendOtp` server action

  **What changed:** `SendOtpResponse` now includes `otpEncryptionTargetBundle`.

  ```ts
  // before
  const { otpId } = await server.sendOtp({ ... });

  // after
  const { otpId, otpEncryptionTargetBundle } = await server.sendOtp({ ... });
  ```

  ***

  ### `verifyOtp` server action

  **What changed:** `otpCode` replaced with `encryptedOtpBundle` in `VerifyOtpRequest`.

  ```ts
  // before
  await server.verifyOtp({
    otpId,
    otpCode: "123456",
    sessionLengthSeconds,
  });

  // after
  import { encryptOtpCodeToBundle } from "@turnkey/crypto";

  const encryptedOtpBundle = await encryptOtpCodeToBundle(
    otpCode, // the code the user entered
    otpEncryptionTargetBundle, // from the sendOtp response
    publicKey, // your target public key
  );

  await server.verifyOtp({
    otpId,
    encryptedOtpBundle,
    sessionLengthSeconds,
  });
  ```

  ***

  ### `otpLogin` server action

  **What changed:** `clientSignature` is now required in `OtpLoginRequest`.

  ```ts
  // before
  await server.otpLogin({
    suborgID,
    verificationToken,
    publicKey,
    sessionLengthSeconds,
  });

  // after
  await server.otpLogin({
    suborgID,
    verificationToken,
    publicKey,
    clientSignature, // new — required
    sessionLengthSeconds,
  });
  ```

- [#1250](https://github.com/tkhq/sdk/pull/1250) [`6128132`](https://github.com/tkhq/sdk/commit/6128132d910f658cdf83ecc1dec6598eb20c008a) Author [@moeodeh3](https://github.com/moeodeh3) - ### `INIT_OTP`

  `ACTIVITY_TYPE_INIT_OTP_V2` → `ACTIVITY_TYPE_INIT_OTP_V3`

  **What changed:** Added required `otpEncryptionTargetBundle` to the result.

  ```ts
  // before — v1InitOtpResult
  {
    otpId: string;
  }

  // after — v1InitOtpResultV2
  {
    otpId: string;
    otpEncryptionTargetBundle: string; // new
  }
  ```

  ***

  ### `VERIFY_OTP`

  `ACTIVITY_TYPE_VERIFY_OTP` → `ACTIVITY_TYPE_VERIFY_OTP_V2`

  **What changed:** Replaced plaintext `otpCode` + `publicKey` with a single `encryptedOtpBundle`.

  Instead of sending the OTP code in plaintext, you now HPKE-encrypt it (along with your public key) to Turnkey's enclave using the `otpEncryptionTargetBundle` returned by `initOtp`. This ensures the OTP code never leaves the client in plaintext.

  Use `encryptOtpCodeToBundle` from `@turnkey/crypto` to build the bundle:

  ```ts
  import { encryptOtpCodeToBundle } from "@turnkey/crypto";

  const { otpId, otpEncryptionTargetBundle } = await client.initOtp({ ... });

  // After the user enters their OTP code:
  const encryptedOtpBundle = await encryptOtpCodeToBundle(
    otpCode,                    // the code the user entered
    otpEncryptionTargetBundle,  // from the initOtp response
    publicKey,                  // your target public key
  );

  await client.verifyOtp({
    otpId,
    encryptedOtpBundle,
  });
  ```

  ```ts
  // before — v1VerifyOtpIntent
  {
    otpId: string;
    otpCode: string;           // removed
    expirationSeconds?: string;
    publicKey?: string;         // removed
  }

  // after — v1VerifyOtpIntentV2
  {
    otpId: string;
    encryptedOtpBundle: string; // new — replaces otpCode + publicKey
    expirationSeconds?: string;
  }
  ```

  ***

  ### `OTP_LOGIN`

  `ACTIVITY_TYPE_OTP_LOGIN` → `ACTIVITY_TYPE_OTP_LOGIN_V2`

  **What changed:** `clientSignature` promoted from optional to required.

  ```ts
  // before — v1OtpLoginIntent
  {
    verificationToken: string;
    publicKey: string;
    expirationSeconds?: string;
    invalidateExisting?: boolean;
    clientSignature?: v1ClientSignature; // optional
  }

  // after — v1OtpLoginIntentV2
  {
    verificationToken: string;
    publicKey: string;
    expirationSeconds?: string;
    invalidateExisting?: boolean;
    clientSignature: v1ClientSignature;  // now required
  }
  ```

  ***

  ### `CREATE_OAUTH_PROVIDERS`

  `ACTIVITY_TYPE_CREATE_OAUTH_PROVIDERS` → `ACTIVITY_TYPE_CREATE_OAUTH_PROVIDERS_V2`

  **What changed:** Added `oidcClaims` as a new option alongside `oidcToken`; you must provide exactly one. This updated type feeds into the `CREATE_SUB_ORGANIZATION` and `CREATE_USERS` changes below.

  ```ts
  // before — v1OauthProviderParams
  {
    providerName: string;
    oidcToken: string;
  }

  // after — v1OauthProviderParamsV2
  {
    providerName: string;
  } & (
    | { oidcToken: string }
    | { oidcClaims: { iss: string; sub: string; aud: string } }
  )
  ```

  ***

  ### `CREATE_SUB_ORGANIZATION`

  `ACTIVITY_TYPE_CREATE_SUB_ORGANIZATION_V7` → `ACTIVITY_TYPE_CREATE_SUB_ORGANIZATION_V8`

  **What changed:** `rootUsers` items updated from `v1RootUserParamsV4` → `v1RootUserParamsV5`, which updates `oauthProviders` from `v1OauthProviderParams` → `v1OauthProviderParamsV2`.

  ```ts
  // before — v1RootUserParamsV4
  {
    userName: string;
    userEmail?: string;
    userPhoneNumber?: string;
    apiKeys: v1ApiKeyParamsV2[];
    authenticators: v1AuthenticatorParamsV2[];
    oauthProviders: {              // v1OauthProviderParams
      providerName: string;
      oidcToken: string;           // was required
    }[];
  }

  // after — v1RootUserParamsV5
  {
    userName: string;
    userEmail?: string;
    userPhoneNumber?: string;
    apiKeys: v1ApiKeyParamsV2[];
    authenticators: v1AuthenticatorParamsV2[];
    oauthProviders: ({             // v1OauthProviderParamsV2
      providerName: string;
    } & (
      | { oidcToken: string }
      | { oidcClaims: { iss: string; sub: string; aud: string } }
    ))[];
  }
  ```

  ***

  ### `CREATE_USERS`

  `ACTIVITY_TYPE_CREATE_USERS_V3` → `ACTIVITY_TYPE_CREATE_USERS_V4`

  **What changed:** `users` items updated from `v1UserParamsV3` → `v1UserParamsV4`, which updates `oauthProviders` from `v1OauthProviderParams` → `v1OauthProviderParamsV2`.

  ```ts
  // before — v1UserParamsV3
  {
    userName: string;
    userEmail?: string;
    userPhoneNumber?: string;
    apiKeys: v1ApiKeyParamsV2[];
    authenticators: v1AuthenticatorParamsV2[];
    oauthProviders: {              // v1OauthProviderParams
      providerName: string;
      oidcToken: string;           // was required
    }[];
    userTags: string[];
  }

  // after — v1UserParamsV4
  {
    userName: string;
    userEmail?: string;
    userPhoneNumber?: string;
    apiKeys: v1ApiKeyParamsV2[];
    authenticators: v1AuthenticatorParamsV2[];
    oauthProviders: ({             // v1OauthProviderParamsV2
      providerName: string;
    } & (
      | { oidcToken: string }
      | { oidcClaims: { iss: string; sub: string; aud: string } }
    ))[];
    userTags: string[];
  }
  ```

### Patch Changes

- [#1225](https://github.com/tkhq/sdk/pull/1225) [`f39e11e`](https://github.com/tkhq/sdk/commit/f39e11eb4dc6dde19516c3f28263528e424672f1) Author [@ethankonk](https://github.com/ethankonk) - Added the `generateWalletAccountsFromAddressFormat` helper which takes in an array of address formats and an array of the current wallet accounts within the wallet and returns a list of deduped `WalletAccountParams`

- Updated dependencies [[`34522d4`](https://github.com/tkhq/sdk/commit/34522d447592138a82d34cd690091315f9748edb), [`7a36539`](https://github.com/tkhq/sdk/commit/7a36539196856a8bd4ca4c54115fa9874ccc83fa), [`47c0ca4`](https://github.com/tkhq/sdk/commit/47c0ca4696c8a518f95550c35cfe4cb4985a2633), [`5624d54`](https://github.com/tkhq/sdk/commit/5624d5417d2cc30032ca4ce71da0a5c7ab9a462d), [`6128132`](https://github.com/tkhq/sdk/commit/6128132d910f658cdf83ecc1dec6598eb20c008a), [`7b80b1e`](https://github.com/tkhq/sdk/commit/7b80b1e9755b83988b5e49c34dff13dd92d9932f)]:
  - @turnkey/sdk-types@1.0.0
  - @turnkey/http@4.0.0
  - @turnkey/api-key-stamper@0.6.6
  - @turnkey/wallet-stamper@1.1.17

## 5.3.0

### Minor Changes

- [#1257](https://github.com/tkhq/sdk/pull/1257) [`d05bd86`](https://github.com/tkhq/sdk/commit/d05bd86400d463c8f8c9788e69f0918db45662b5) Thanks [@Bijan-Massoumi](https://github.com/Bijan-Massoumi)! - Expose `pollTransactionStatus()` in client

### Patch Changes

- [#1269](https://github.com/tkhq/sdk/pull/1269) [`ef66673`](https://github.com/tkhq/sdk/commit/ef6667325d210c8aa0ea4c1d11d834ff28ddb66c) Author [@ethankonk](https://github.com/ethankonk) - Sync with v2026.4.5 of mono

- Updated dependencies [[`ef66673`](https://github.com/tkhq/sdk/commit/ef6667325d210c8aa0ea4c1d11d834ff28ddb66c), [`8209887`](https://github.com/tkhq/sdk/commit/8209887d48bae7ea617645603a156aeb1cfbd2e7)]:
  - @turnkey/sdk-types@0.14.0
  - @turnkey/http@3.18.1
  - @turnkey/wallet-stamper@1.1.16
  - @turnkey/api-key-stamper@0.6.5

## 5.2.0

### Minor Changes

- [#1252](https://github.com/tkhq/sdk/pull/1252) [`46b4d2f`](https://github.com/tkhq/sdk/commit/46b4d2fa807fb87d06bb606623ba1f86582aa4ef) Author [@ethankonk](https://github.com/ethankonk) - Sync as per mono v2026.3.6

### Patch Changes

- Updated dependencies [[`46b4d2f`](https://github.com/tkhq/sdk/commit/46b4d2fa807fb87d06bb606623ba1f86582aa4ef)]:
  - @turnkey/http@3.18.0
  - @turnkey/wallet-stamper@1.1.15
  - @turnkey/api-key-stamper@0.6.4

## 5.1.1

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.3
  - @turnkey/wallet-stamper@1.1.14
  - @turnkey/http@3.17.1

## 5.1.0

### Minor Changes

- [#1206](https://github.com/tkhq/sdk/pull/1206) [`58e04e5`](https://github.com/tkhq/sdk/commit/58e04e5856626d9d2593abb61d8ca32d8ccbb833) Author [@DeRauk](https://github.com/DeRauk) - Adds sdk methods for the GetWalletAddressBalances and ListSupportedAssets apis.

### Patch Changes

- [#1201](https://github.com/tkhq/sdk/pull/1201) [`1f6e240`](https://github.com/tkhq/sdk/commit/1f6e2403fca1fd9cbca646f88c88dbc49ddb0c34) Author [@ethankonk](https://github.com/ethankonk) - Synced with Mono v2026.2.0

- [#1197](https://github.com/tkhq/sdk/pull/1197) [`7458b7c`](https://github.com/tkhq/sdk/commit/7458b7cd6fc64796b376e3374b7c2ed79467459c) Thanks [@moe-dev](https://github.com/moe-dev)! - Add support for SolSendTransaction and associated abstractions

- Updated dependencies [[`1f6e240`](https://github.com/tkhq/sdk/commit/1f6e2403fca1fd9cbca646f88c88dbc49ddb0c34), [`58e04e5`](https://github.com/tkhq/sdk/commit/58e04e5856626d9d2593abb61d8ca32d8ccbb833), [`7458b7c`](https://github.com/tkhq/sdk/commit/7458b7cd6fc64796b376e3374b7c2ed79467459c)]:
  - @turnkey/http@3.17.0
  - @turnkey/wallet-stamper@1.1.13
  - @turnkey/api-key-stamper@0.6.2

## 5.0.3

### Patch Changes

- [#1194](https://github.com/tkhq/sdk/pull/1194) [`dced9db`](https://github.com/tkhq/sdk/commit/dced9dbbd8ea533442e19e45ce36e6a05a45a555) Author [@moeodeh3](https://github.com/moeodeh3) - Add `Content-Type: application/json` header to all Turnkey API requests

- Updated dependencies [[`dced9db`](https://github.com/tkhq/sdk/commit/dced9dbbd8ea533442e19e45ce36e6a05a45a555)]:
  - @turnkey/http@3.16.3
  - @turnkey/wallet-stamper@1.1.12

## 5.0.2

### Patch Changes

- [#1173](https://github.com/tkhq/sdk/pull/1173) [`4742eaf`](https://github.com/tkhq/sdk/commit/4742eafbfdcc6fe6b6d3aab01569ad94a5198571) Author [@ethankonk](https://github.com/ethankonk) - Fix polling logic to use the `organizationId` from the activity response instead of the config, which fixes activity polling for auth functions

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.6.1
  - @turnkey/wallet-stamper@1.1.12
  - @turnkey/http@3.16.2

## 5.0.1

### Patch Changes

- Updated dependencies [[`91d6a9e`](https://github.com/tkhq/sdk/commit/91d6a9eb1b9ac9e21745749615ac7a7be66f5cf6)]:
  - @turnkey/api-key-stamper@0.6.0
  - @turnkey/wallet-stamper@1.1.11
  - @turnkey/http@3.16.1

## 5.0.0

### Major Changes

- [#1153](https://github.com/tkhq/sdk/pull/1153) [`78ec1d9`](https://github.com/tkhq/sdk/commit/78ec1d9afcafde3ca7107fc720323d486d6afaea) Thanks [@moe-dev](https://github.com/moe-dev)! - Update as per mono v2025.12.3.

  ### Breaking/Behavioral Changes
  - `appName` is now **required**:
    - In `emailCustomization` for Email Auth activities
    - At the top-level intent for OTP activities
  - Auth proxy endpoints are **not affected**

  ### Activity Version Bumps

  The following activity types have been versioned:
  - `ACTIVITY_TYPE_INIT_OTP` → `ACTIVITY_TYPE_INIT_OTP_V2`
  - `ACTIVITY_TYPE_INIT_OTP_AUTH_V2` → `ACTIVITY_TYPE_INIT_OTP_V3`
  - `ACTIVITY_TYPE_EMAIL_AUTH_V2` → `ACTIVITY_TYPE_EMAIL_AUTH_V3`
  - `ACTIVITY_TYPE_INIT_USER_EMAIL_RECOVERY` -> `ACTIVITY_TYPE_INIT_USER_EMAIL_RECOVERY_V2`

### Patch Changes

- [#1145](https://github.com/tkhq/sdk/pull/1145) [`dbd4d8e`](https://github.com/tkhq/sdk/commit/dbd4d8e4ea567240c4d287452dd0d8f53050beca) Author [@moeodeh3](https://github.com/moeodeh3) - Stamp function improvements
  - Queries: add `organizationId` fallback from config
  - Activities: fix request structure to include the `parameters wrapper`, `organizationId`, `timestampMs`, and `type` fields

- Updated dependencies [[`78ec1d9`](https://github.com/tkhq/sdk/commit/78ec1d9afcafde3ca7107fc720323d486d6afaea)]:
  - @turnkey/http@3.16.0
  - @turnkey/wallet-stamper@1.1.10

## 4.12.2

### Patch Changes

- Updated dependencies []:
  - @turnkey/wallet-stamper@1.1.9

## 4.12.1

### Patch Changes

- Updated dependencies []:
  - @turnkey/wallet-stamper@1.1.8

## 4.12.0

### Minor Changes

- [#1072](https://github.com/tkhq/sdk/pull/1072) [`67b03a5`](https://github.com/tkhq/sdk/commit/67b03a5d9ab1b6eabfb0b41938ac91365b5dcd9b) Thanks [@moe-dev](https://github.com/moe-dev)! - Bump packages as per mono v2025.11.0

### Patch Changes

- Updated dependencies [[`67b03a5`](https://github.com/tkhq/sdk/commit/67b03a5d9ab1b6eabfb0b41938ac91365b5dcd9b)]:
  - @turnkey/http@3.15.0
  - @turnkey/wallet-stamper@1.1.7

## 4.11.0

### Minor Changes

- [#1063](https://github.com/tkhq/sdk/pull/1063) [`71cdca3`](https://github.com/tkhq/sdk/commit/71cdca3b97ba520dc5327410a1e82cf9ad85fb0e) Author [@zkharit](https://github.com/zkharit) - Omit optional email parameter if not set

- [#1058](https://github.com/tkhq/sdk/pull/1058) [`9fbd5c4`](https://github.com/tkhq/sdk/commit/9fbd5c459782dc3721dd0935d0a4458babce258b) Author [@moeodeh3](https://github.com/moeodeh3) - Update per mono release `v2025.10.10-hotfix.2`

### Patch Changes

- Updated dependencies [[`9fbd5c4`](https://github.com/tkhq/sdk/commit/9fbd5c459782dc3721dd0935d0a4458babce258b)]:
  - @turnkey/http@3.14.0
  - @turnkey/wallet-stamper@1.1.6

## 4.10.5

### Patch Changes

- Updated dependencies []:
  - @turnkey/wallet-stamper@1.1.6

## 4.10.4

### Patch Changes

- Updated dependencies []:
  - @turnkey/wallet-stamper@1.1.5

## 4.10.3

### Patch Changes

- [#1016](https://github.com/tkhq/sdk/pull/1016) [`9df42ad`](https://github.com/tkhq/sdk/commit/9df42adc02c7ff77afba3b938536e79b57882ef1) Author [@amircheikh](https://github.com/amircheikh) - Synced API as per mono v2025.10.2

- Updated dependencies [[`9df42ad`](https://github.com/tkhq/sdk/commit/9df42adc02c7ff77afba3b938536e79b57882ef1)]:
  - @turnkey/http@3.13.1
  - @turnkey/wallet-stamper@1.1.4

## 4.10.2

### Patch Changes

- Updated dependencies []:
  - @turnkey/wallet-stamper@1.1.3

## 4.10.1

### Patch Changes

- Updated dependencies []:
  - @turnkey/wallet-stamper@1.1.2

## 4.10.0

### Minor Changes

- [#977](https://github.com/tkhq/sdk/pull/977) [`4567059`](https://github.com/tkhq/sdk/commit/45670598f102223925b87a5295edca15a6ce8241) Author [@besler613](https://github.com/besler613) - OAuth2Authenticate now supports returning the encrypted bearer token via the optional `bearerTokenTargetPublicKey` request parameter (mono release v2025.9.5)

### Patch Changes

- Updated dependencies [[`4567059`](https://github.com/tkhq/sdk/commit/45670598f102223925b87a5295edca15a6ce8241)]:
  - @turnkey/http@3.13.0
  - @turnkey/wallet-stamper@1.1.1

## 4.9.1

### Patch Changes

- [#958](https://github.com/tkhq/sdk/pull/958) [`5a96fe8`](https://github.com/tkhq/sdk/commit/5a96fe80db4c4c45e09ad8c613695ee4c2b8e51f) Author [@amircheikh](https://github.com/amircheikh) - - Synced api with mono

- Updated dependencies [[`5a96fe8`](https://github.com/tkhq/sdk/commit/5a96fe80db4c4c45e09ad8c613695ee4c2b8e51f)]:
  - @turnkey/http@3.12.1
  - @turnkey/wallet-stamper@1.1.1

## 4.9.0

### Minor Changes

- Updated dependencies [[`fc1d6e2`](https://github.com/tkhq/sdk/commit/fc1d6e2d26f4a53116633e9e8cccccd792267f4e), [`fc1d6e2`](https://github.com/tkhq/sdk/commit/fc1d6e2d26f4a53116633e9e8cccccd792267f4e), [`06347ad`](https://github.com/tkhq/sdk/commit/06347adfa08fb0867c350e43821d0fed06c49624)]:
  - @turnkey/http@3.12.0
  - @turnkey/api-key-stamper@0.5.0
  - @turnkey/wallet-stamper@1.1.0

## 4.8.1-beta.0

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.5.0-beta.6
  - @turnkey/http@3.11.1-beta.0
  - @turnkey/wallet-stamper@1.1.0-beta.6

## 4.8.0

### Minor Changes

- [#879](https://github.com/tkhq/sdk/pull/879) [`026264c`](https://github.com/tkhq/sdk/commit/026264c55aa16342c8925af0bdcdf72dc00e5158) Author [@zkharit](https://github.com/zkharit) - Update packages to include new activities as of the newest release (mono v2025.8.10)

### Patch Changes

- Updated dependencies [[`026264c`](https://github.com/tkhq/sdk/commit/026264c55aa16342c8925af0bdcdf72dc00e5158)]:
  - @turnkey/http@3.11.0
  - @turnkey/wallet-stamper@1.0.9

## 4.7.0-beta.2

### Minor Changes

- SDK beta release @turnkey/react-wallet-kit @turnkey/core

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.5.0-beta.5
  - @turnkey/wallet-stamper@1.1.0-beta.5
  - @turnkey/http@3.10.0-beta.2

## 4.7.0-beta.1

### Minor Changes

- @turnkey/react-wallet-kit and @turnkey/core beta-3 release

### Patch Changes

- Updated dependencies []:
  - @turnkey/http@3.10.0-beta.1
  - @turnkey/api-key-stamper@0.4.8-beta.4
  - @turnkey/wallet-stamper@1.0.9-beta.4

## 4.7.0-beta.0

### Minor Changes

- @turnkey/react-wallet-kit and @turnkey/core beta-3 release

### Patch Changes

- Updated dependencies []:
  - @turnkey/http@3.10.0-beta.0
  - @turnkey/api-key-stamper@0.4.8-beta.3
  - @turnkey/wallet-stamper@1.0.9-beta.3

## 4.7.0

### Minor Changes

- [#861](https://github.com/tkhq/sdk/pull/861) [`5d8be2d`](https://github.com/tkhq/sdk/commit/5d8be2d0329070c7aa025dddb1b28f04257ae4e6) Author [@amircheikh](https://github.com/amircheikh) - Synced as per mono 2025.8.4

### Patch Changes

- Updated dependencies [[`5d8be2d`](https://github.com/tkhq/sdk/commit/5d8be2d0329070c7aa025dddb1b28f04257ae4e6)]:
  - @turnkey/http@3.10.0
  - @turnkey/wallet-stamper@1.0.8

## 4.6.0

### Minor Changes

- [#834](https://github.com/tkhq/sdk/pull/834) [`8b39dba`](https://github.com/tkhq/sdk/commit/8b39dbabf68d3e376b5b07f26960d5b61ae87fa9) Author [@moeodeh3](https://github.com/moeodeh3) - Update per mono release v2025.8.3-hotfix.0

### Patch Changes

- [#833](https://github.com/tkhq/sdk/pull/833) [`1a549b7`](https://github.com/tkhq/sdk/commit/1a549b71f9a6e7ab59d52aaae7e58e34c8f2e8b5) Author [@moeodeh3](https://github.com/moeodeh3) - Add optional `includeUnverified` parameter to `getOrCreateSuborg()` to allow inclusion of unverified subOrgs

- Updated dependencies [[`8b39dba`](https://github.com/tkhq/sdk/commit/8b39dbabf68d3e376b5b07f26960d5b61ae87fa9)]:
  - @turnkey/http@3.9.0
  - @turnkey/wallet-stamper@1.0.8

## 4.5.1-beta.2

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.4.8-beta.2
  - @turnkey/http@3.8.1-beta.2
  - @turnkey/wallet-stamper@1.0.9-beta.2

## 4.5.1-beta.0

### Patch Changes

- Updated dependencies []:
  - @turnkey/api-key-stamper@0.4.8-beta.0
  - @turnkey/http@3.8.1-beta.0
  - @turnkey/wallet-stamper@1.0.9-beta.0

## 4.5.0

### Minor Changes

- [#826](https://github.com/tkhq/sdk/pull/826) [`f83f25b`](https://github.com/tkhq/sdk/commit/f83f25ba33ef15dbd66723531eebe2fd00f43ac0) Author [@turnekybc](https://github.com/turnekybc) - Update per mono release v2025.8.1

### Patch Changes

- Updated dependencies [[`f83f25b`](https://github.com/tkhq/sdk/commit/f83f25ba33ef15dbd66723531eebe2fd00f43ac0)]:
  - @turnkey/http@3.8.0
  - @turnkey/wallet-stamper@1.0.8

## 4.4.0

### Minor Changes

- [#651](https://github.com/tkhq/sdk/pull/651) [`81e355c`](https://github.com/tkhq/sdk/commit/81e355c9a8321feffcac056916b65139cf35eeed) Author [@turnekybc](https://github.com/turnekybc) - Add Coinbase & MoonPay Fiat Onramp. View the [Fiat Onramp feature docs](https://docs.turnkey.com/wallets/fiat-on-ramp).

### Patch Changes

- Updated dependencies [[`81e355c`](https://github.com/tkhq/sdk/commit/81e355c9a8321feffcac056916b65139cf35eeed)]:
  - @turnkey/http@3.7.0
  - @turnkey/wallet-stamper@1.0.8

## 4.3.0

### Minor Changes

- [#782](https://github.com/tkhq/sdk/pull/782) [`e90a478`](https://github.com/tkhq/sdk/commit/e90a478c9208d858b1144df9b2c2c7ba956c406e) Thanks [@r-n-o](https://github.com/r-n-o)! - Release v2025.7.16

### Patch Changes

- Updated dependencies [[`e90a478`](https://github.com/tkhq/sdk/commit/e90a478c9208d858b1144df9b2c2c7ba956c406e)]:
  - @turnkey/http@3.6.0
  - @turnkey/wallet-stamper@1.0.7

## 4.2.4

### Patch Changes

- [#780](https://github.com/tkhq/sdk/pull/780) [`2db00b0`](https://github.com/tkhq/sdk/commit/2db00b0a799d09ae33fa08a117e3b2f433f2b0b4) Thanks [@moe-dev](https://github.com/moe-dev)! - Patch fix for server actions leading to unwanted suborg creation when query requests time out

## 4.2.3

### Patch Changes

- [#763](https://github.com/tkhq/sdk/pull/763) [`cb13c26`](https://github.com/tkhq/sdk/commit/cb13c26edb79a01ab651e3b2897334fd154b436a) Author [@andrewkmin](https://github.com/andrewkmin) - Release per mono v2025.7.1. This release contains the following API changes:
  - Introduction of `SmartContractInterfaces`: we've now exposed endpoints for uploading ABIs and IDLs to help secure EVM and Solana signing flows. For more information, see our docs [here](https://docs.turnkey.com/concepts/policies/smart-contract-interfaces)

- Updated dependencies [[`cb13c26`](https://github.com/tkhq/sdk/commit/cb13c26edb79a01ab651e3b2897334fd154b436a)]:
  - @turnkey/http@3.5.1
  - @turnkey/wallet-stamper@1.0.7

## 4.2.2

### Patch Changes

- Updated dependencies []:
  - @turnkey/wallet-stamper@1.0.7

## 4.2.1

### Patch Changes

- Updated dependencies []:
  - @turnkey/wallet-stamper@1.0.6

## 4.2.0

### Minor Changes

- [#704](https://github.com/tkhq/sdk/pull/704) [`5f3dd98`](https://github.com/tkhq/sdk/commit/5f3dd9814650308b3bf3198168c453e7b1a98efd) Author [@amircheikh](https://github.com/amircheikh) - Synced with mono 2025.6.10 to include the following endpoints:

  `update_user_email`: Update a User's email in an existing Organization

  `update_user_name`: Update a User's name in an existing Organization

  `update_user_phone_number`: Update a User's phone number in an existing Organization

### Patch Changes

- [#698](https://github.com/tkhq/sdk/pull/698) [`7625df0`](https://github.com/tkhq/sdk/commit/7625df0538002c3455bd5862211210e38472e164) Author [@moeodeh3](https://github.com/moeodeh3) - Introduces an optional `runtimeOverride` parameter that allows the ability to explicitly specify the crypto environment: `"browser"`, `"node"`, or `"purejs"`.

- Updated dependencies [[`5f3dd98`](https://github.com/tkhq/sdk/commit/5f3dd9814650308b3bf3198168c453e7b1a98efd), [`7625df0`](https://github.com/tkhq/sdk/commit/7625df0538002c3455bd5862211210e38472e164)]:
  - @turnkey/http@3.5.0
  - @turnkey/api-key-stamper@0.4.7
  - @turnkey/wallet-stamper@1.0.5

## 4.1.1

### Patch Changes

- Updated dependencies [[`be0a621`](https://github.com/tkhq/sdk/commit/be0a621fb962bd51d2df1a1e79f5260d7c696772)]:
  - @turnkey/http@3.4.2
  - @turnkey/wallet-stamper@1.0.4

## 4.1.0

### Minor Changes

- [#632](https://github.com/tkhq/sdk/pull/632) [`a38a6e3`](https://github.com/tkhq/sdk/commit/a38a6e36dc2bf9abdea64bc817d1cad95b8a289a) Author [@amircheikh](https://github.com/amircheikh) - Exposed `createOauthProviders` and `getUsers` as server actions. These are used for social linking within `@turnkey/sdk-react`.

### Patch Changes

- [#663](https://github.com/tkhq/sdk/pull/663) [`593de2d`](https://github.com/tkhq/sdk/commit/593de2d9404ec8cf53426f9cf832c13eefa3fbf2) Thanks [@moe-dev](https://github.com/moe-dev)! - Update to endpoints as per mono v2025.5.7. Add V5 TON address format generation. Non breaking

- Updated dependencies [[`5afbe51`](https://github.com/tkhq/sdk/commit/5afbe51949bdd1997fad083a4c1e4272ff7409dc), [`593de2d`](https://github.com/tkhq/sdk/commit/593de2d9404ec8cf53426f9cf832c13eefa3fbf2)]:
  - @turnkey/wallet-stamper@1.0.4
  - @turnkey/http@3.4.1
  - @turnkey/api-key-stamper@0.4.6

## 4.0.1

### Patch Changes

- Update @turnkey/sdk-types readme and install dependency in packages with common types

- [#650](https://github.com/tkhq/sdk/pull/650) [`27fe590`](https://github.com/tkhq/sdk/commit/27fe590cdc3eb6a8cde093eeefda2ee1cdc79412) Author [@turnekybc](https://github.com/turnekybc) - Update @turnkey/sdk-types readme and install dependency in packages with common types

## 4.0.0

### Major Changes

- [#601](https://github.com/tkhq/sdk/pull/601) [`07dfd33`](https://github.com/tkhq/sdk/commit/07dfd3397472687092e1c73b1d68714f421b9ca0) Author [@moe-dev](https://github.com/moe-dev).

This release introduces significant updates and new actions to the SDK server methods, enhancing authentication flows and simplifying usage:

**Updated Actions:**

- `sendOtp`: No longer requires a suborganization ID; OTPs can now be sent directly under a parent organization's context to any email or phone number.

- `verifyOtp`: Now returns a `verificationToken`, which is required for creating sessions via the new `otpLogin` action.

**New Actions:**

- `otpLogin`: Creates a session using a previously obtained `verificationToken`. Returns a session JWT.

- `oauthLogin`: Authenticates using an OIDC token obtained from a third-party provider (e.g., Google, Apple, Facebook). Returns a session JWT.

These changes standardize authentication processes, simplify integration, and streamline session management across the SDK.

### Patch Changes

- [#631](https://github.com/tkhq/sdk/pull/631) [`e8a5f1b`](https://github.com/tkhq/sdk/commit/e8a5f1b431623c4ff1cb85c6039464b328cf0e6a) Author [@andrewkmin](https://github.com/andrewkmin) - Remove unused Next.js dependency
  - while the `"use server"` directive in `actions.ts` is to be used specifically with Next, removing it from this package (`@turnkey/sdk-server`) is fine, though applications _using_ this package will need Next.js

- Updated dependencies [[`07dfd33`](https://github.com/tkhq/sdk/commit/07dfd3397472687092e1c73b1d68714f421b9ca0)]:
  - @turnkey/http@3.4.0
  - @turnkey/wallet-stamper@1.0.3

## 3.3.0

### Minor Changes

- 25ca339: Adding replyToEmailAddress field for specifying reply-to when using a customer sender

### Patch Changes

- Updated dependencies [25ca339]
  - @turnkey/http@3.3.0
  - @turnkey/wallet-stamper@1.0.3

## 3.2.0

### Minor Changes

- 3f6e415: Update per mono v2025.4.5

### Patch Changes

- Updated dependencies [3f6e415]
- Updated dependencies [4d1d775]
  - @turnkey/http@3.2.0
  - @turnkey/api-key-stamper@0.4.5
  - @turnkey/wallet-stamper@1.0.3

## 3.1.0

### Minor Changes

- 3e4a482: Release per mono v2025.4.4

### Patch Changes

- Updated dependencies [3e4a482]
  - @turnkey/http@3.1.0
  - @turnkey/wallet-stamper@1.0.3

## 3.0.1

### Patch Changes

- 7b72769: Add sendFromEmailSenderName to sendOtp server action

## 3.0.0

### Major Changes

- d1083bd: initOtpAuth now defaults to v2 (breaking) which allows alphanumeric boolean and otpLength (6-9) to be passed + associated updates to server actions. More details below.

- This release introduces the `INIT_OTP_AUTH_V2` activity. The difference between it and `INIT_OTP_AUTH` is that it can now accept `alphanumeric` and `otpLength` for selecting crockford bech32 alphanumeric codes and the length of those codes. By default alphanumeric = true, otpLength = 9

- This release introduces `sendFromEmailSenderName` to `INIT_OTP_AUTH`, `INIT_OTP_AUTH_V2`, `EMAIL_AUTH` and `EMAIL_AUTH_V2`. This is an optional custom sender name for use with sendFromEmailAddress; if left empty, will default to 'Notifications'.

### Patch Changes

- Updated dependencies [d1083bd]
- Updated dependencies [f94d36e]
  - @turnkey/http@3.0.0
  - @turnkey/wallet-stamper@1.0.3

## 2.6.1

### Patch Changes

- 5ec5187: Fix initOtpAuth bug with improper version result (to be updated to V2 following release r2025.3.8)

## 2.6.0

### Minor Changes

- ecdb29a: Update API as per mono v2025.3.2 - Add CREATE_USERS_V3

### Patch Changes

- 0e4e959: bump update policy activity to v2
- c9ae537: Update nextJs to >= 15.2.3 as per github advisory: https://github.com/advisories/GHSA-f82v-jwr5-mffw

  For Next.js 15.x, this issue is fixed in 15.2.3
  For Next.js 14.x, this issue is fixed in 14.2.25
  For Next.js 13.x, this issue is fixed in 13.5.9
  For Next.js 12.x, this issue is fixed in 12.3.5

- 72890f5: ### @turnkey/sdk-browser
  - Move all type definitions to [`./__types__/base.ts`](https://github.com/tkhq/sdk/blob/494911d948d0a53c0d00aa01e9821aefd5e3f80d/packages/sdk-browser/src/__types__/base.ts)
  - `TurnkeyBrowserClient`
    - `refereshSession()` now consumes a [RefreshSessionParams](https://github.com/tkhq/sdk/blob/494911d948d0a53c0d00aa01e9821aefd5e3f80d/packages/sdk-browser/src/__types__/base.ts#L213) parameter
    - `loginWithBundle()` now consumes a [LoginWithBundleParams](https://github.com/tkhq/sdk/blob/494911d948d0a53c0d00aa01e9821aefd5e3f80d/packages/sdk-browser/src/__types__/base.ts#L219) parameter
    - `loginWithPasskey()` now consumes a [LoginWithPasskeyParams](https://github.com/tkhq/sdk/blob/494911d948d0a53c0d00aa01e9821aefd5e3f80d/packages/sdk-browser/src/__types__/base.ts#L224) parameter
    - `loginWithWallet()` now consumes a [LoginWithWalletParams](https://github.com/tkhq/sdk/blob/494911d948d0a53c0d00aa01e9821aefd5e3f80d/packages/sdk-browser/src/__types__/base.ts#L231) parameter

  ### @turnkey/sdk-react
  - `Auth.tsx`
    - updated `passkeyClient?.loginWithPasskey()` to implement new method signature
    - updated `walletClient?.loginWithWallet()` to implement new method signature

  ### @turnkey/sdk-server
  - Move all type definitions to [`./__types__/base.ts`](https://github.com/tkhq/sdk/blob/494911d948d0a53c0d00aa01e9821aefd5e3f80d/packages/sdk-server/src/__types__/base.ts)

- Updated dependencies [ecdb29a]
  - @turnkey/http@2.22.0
  - @turnkey/wallet-stamper@1.0.3

## 2.5.0

### Minor Changes

- 93540e7: ## Major Package Updates

  ### @turnkey/sdk-browser
  - create abstract `TurnkeyBaseClient` class which extends `TurnkeySDKClientBase`
    - `TurnkeyBrowserClient`, `TurnkeyIframeClient`, `TurnkeyPasskeyClient`, and `TurnkeyWalletClient` all extend `TurnkeyBaseClient`
  - TurnkeyBrowserClient
    - Session Management
      - `refreshSession` - attempts to refresh an existing, active session and will extend the session expiry using the `expirationSeconds` parameter
      - loginWithBundle - authenticate a user via a credential bundle and creates a read-write session
      - loginWithPasskey - attempts to authenticate a user via passkey and create a read-only or read-write session
      - loginWithSession - takes a `Session`, which can be either read-only or read-write, created via a server action and attempts to authenticate the user
  - TurnkeyPasskeyClient
    - Session Management
      - createPasskeySession - leverages passkey authentication to create a read-write session. Once authenticated, the user will not be prompted for additional passkey taps.

  ### @turnkey/sdk-react
  - update `TurnkeyContext` to use new `.getSession()` method to check if there is an active session
  - `OTPVerification` component no longer receives `authIframeClient` or `onValidateSuccess` props

  ## Minor Package Updates

  ### @turnkey/sdk-server
  - expose `sendCredential` server action
  - add `SessionType` enum
    - `READ_ONLY` & `READ_WRITE`

  ### @turnkey/eip-1193-provider
  - update dependencies in `package.json`
    - moved from `peerDependencies` to `dependencies`
      - `"@turnkey/http": "workspace:*"`
      - `"@turnkey/sdk-browser": "workspace:*"`
    - moved from `devDependencies` to `dependencies`
      - `"@turnkey/api-key-stamper": "workspace:*"`
  - specify TypeScript version ^5.1.5

### Patch Changes

- fdb8bf0: Add loading indicators for EWK. Exposed email customization to EWK.

## 2.4.0

### Minor Changes

- 9317588: Adds wallet as an authentication option in the Embedded Wallet Kit components for sdk-react

## 2.3.0

### Minor Changes

- 56a307e: Update api to mono v2025.3.0

### Patch Changes

- Updated dependencies [56a307e]
  - @turnkey/http@2.21.0

## 2.2.0

### Minor Changes

- 3c44c4a: Updates per mono release v2025.2.2

### Patch Changes

- bfc833f: Add getOrCreateSuborg server action
- Updated dependencies [3c44c4a]
  - @turnkey/http@2.20.0

## 2.1.0

### Minor Changes

- 57f9cb0: Update endpoints - surface GetWalletAccount

### Patch Changes

- 69d2571: Upgrade elliptic
- Updated dependencies [57f9cb0]
  - @turnkey/http@2.19.0

## 2.0.1

### Patch Changes

- 755833b: refactor stamper out of config object and move it directly onto the client to match @turnkey/http

## 2.0.0

### Major Changes

- 1ebd4e2: Add server actions

### Minor Changes

- 6695af2: Update per mono release v2025.1.11

### Patch Changes

- Updated dependencies [6695af2]
  - @turnkey/http@2.18.0

## 1.7.3

### Patch Changes

- 053fbfb: Update mono dependencies
- Updated dependencies [053fbfb]
  - @turnkey/http@2.17.3

## 1.7.2

### Patch Changes

- 328d6aa: Add defaultXrpAccountAtIndex helper
- b90947e: Update default account exports, surface WalletAccount type
- fad7c37: @turnkey/iframe-stamper - Implemented MessageChannel API for secure communication between the parent and iframe.

  @turnkey/sdk-browser - fixed spelling in package.json
  @turnkey/sdk-server - fixed spelling in package.json

- Updated dependencies [2d5977b]
  - @turnkey/api-key-stamper@0.4.4
  - @turnkey/http@2.17.2

## 1.7.1

### Patch Changes

- 538d4fc: Update api endpoints - NEW: User verification, SMS customization params
- Updated dependencies [538d4fc]
  - @turnkey/http@2.17.1

## 1.7.0

### Minor Changes

- 78bc39c: Add default accounts for various address types
  - Add wallet account ID to list wallets endpoint

### Patch Changes

- Updated dependencies [78bc39c]
  - @turnkey/http@2.17.0

## 1.6.0

### Minor Changes

- 3dd74ac: Added functionality for constructing and returning stamped requests for all packages
- 4df8914: Version bump corresponding to mono release v2024.10.10. More detailed changelog to follow

### Patch Changes

- Updated dependencies [4df8914]
  - @turnkey/http@2.16.0

## 1.5.0

### Minor Changes

- 9ebd062: Release OTP functionality

### Patch Changes

- Updated dependencies [9ebd062]
  - @turnkey/http@2.15.0

## 1.4.2

### Patch Changes

- abe7138: Export DEFAULT_SOLANA_ACCOUNTS
- 96d7f99: Update dependencies
- Updated dependencies [96d7f99]
  - @turnkey/http@2.14.2
  - @turnkey/api-key-stamper@0.4.3

## 1.4.1

### Patch Changes

- ff059d5: Update dependencies
- Updated dependencies [ff059d5]
  - @turnkey/http@2.14.1
  - @turnkey/api-key-stamper@0.4.2

## 1.4.0

### Minor Changes

- c988ed0: Support activity polling (e.g. for awaiting consensus)
  - [Breaking] Update the `activityPoller` parameter for configuring polling behavior
  - Polling continues until either a max number of retries is reached, or if the activity hits a terminal status

  The shape of the parameter has gone from:

  ```
  {
    duration: number;
    timeout: number;
  }
  ```

  to

  ```
  {
    intervalMs: number;
    numRetries: number;
  }
  ```

### Patch Changes

- Updated dependencies [848f8d3]
  - @turnkey/http@2.14.0

## 1.3.0

### Minor Changes

- 93dee46: Add create read write session v2 which allows for user targeting directly from stamp or optional userId in intent

### Patch Changes

- Updated dependencies [93dee46]
  - @turnkey/http@2.13.0

## 1.2.4

### Patch Changes

- Updated dependencies [e2f2e0b]
  - @turnkey/http@2.12.3

## 1.2.3

### Patch Changes

- Fix activity versioning for CREATE_SUB_ORGANIZATION (V5=>V6)

## 1.2.2

### Patch Changes

- Updated dependencies [2d7e5a9]
  - @turnkey/api-key-stamper@0.4.1
  - @turnkey/http@2.12.2

## 1.2.1

### Patch Changes

- f17a229: Update to oauth related endpoints to drop jwks uri from oauth providers
- Updated dependencies [f17a229]
  - @turnkey/http@2.12.1

## 1.2.0

### Minor Changes

- Add Email Auth V2 - Optional invalidate exisiting Email Authentication API keys

### Patch Changes

- Updated dependencies
  - @turnkey/http@2.12.0

## 1.1.0

### Minor Changes

- Update to use new endpoints. Including CREATE_READ_WRITE_SESSION which allows one shot passkey sessions (returns org information and a credential bundle) and CREATE_API_KEYS_V2 which allows a curve type to be passed (SECP256K1 or P256)

### Patch Changes

- Updated dependencies
  - @turnkey/http@2.11.0

## 1.0.0

### Major Changes

- Stable Release: Add Oauth integration. New suborg creation version will now require an oauthProviders field under root users.

## 0.2.0

### Minor Changes

- updated syntax

### Patch Changes

- e4d2a84: Update client name

## 0.1.0

### Minor Changes

- Ready for 0.1.0

## 0.0.1

Initial (experimental) release! This is an alpha release and subject to change.
