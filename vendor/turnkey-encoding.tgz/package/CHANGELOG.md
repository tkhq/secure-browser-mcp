# @turnkey/encoding

## 0.6.0

### Minor Changes

- [#886](https://github.com/tkhq/sdk/pull/886) [`6bfcbc5`](https://github.com/tkhq/sdk/commit/6bfcbc5c098e64ab1d115518733b87cfc1653e17) Author [@moeodeh3](https://github.com/moeodeh3) - Expose `bs58` and `bs58check` shims for cross-platform usage.

## 0.6.0-beta.6

### Minor Changes

- @turnkey/react-wallet-kit and @turnkey/core beta release

## 0.6.0-beta.5

### Minor Changes

- SDK beta release @turnkey/react-wallet-kit @turnkey/core

## 0.6.0-beta.4

### Minor Changes

- @turnkey/react-wallet-kit and @turnkey/core beta-3 release

## 0.6.0-beta.3

### Minor Changes

- @turnkey/react-wallet-kit and @turnkey/core beta-3 release

## 0.6.0-beta.2

### Minor Changes

- updating package versions

## 0.6.0-beta.1

### Minor Changes

- test build

## 0.6.0-beta.0

### Minor Changes

- beta for @turnkey/react-wallet-kit and @turnkey/core

## 0.5.0

### Minor Changes

- [#653](https://github.com/tkhq/sdk/pull/653) [`40c4035`](https://github.com/tkhq/sdk/commit/40c40359ec7096d0bca39ffc93e89361b3b11a1a) Thanks [@moe-dev](https://github.com/moe-dev)! - Add pointEncode function

## 0.4.0

### Minor Changes

- added hexToAscii function, useful for converting a raw hex string to a (wallet) mnemonic

## 0.3.0

### Minor Changes

- 93666ff: turnkey/crypto standard HPKE encryption, first major release. Allows for programmatic importing in environments like node. Moved some encoding helper functions to turnkey/encoding

## 0.2.1

### Patch Changes

- 2d7e5a9: include additional utility functions

## 0.2.0

### Minor Changes

- fac7770: Add uint8ArrayFromHexstring and drop language saying this is an internal package

## 0.1.0

Initial release
