# @turnkey/api-key-stamper

## 0.6.13

### Patch Changes

- Updated dependencies [[`3af9589`](https://github.com/tkhq/sdk/commit/3af958959c2827d3404525fd22d73be5e306111c), [`35f9cce`](https://github.com/tkhq/sdk/commit/35f9cce418b3704d8e77840c0d76b325079982cb)]:
  - @turnkey/crypto@2.12.0

## 0.6.12

### Patch Changes

- Updated dependencies []:
  - @turnkey/crypto@2.11.3

## 0.6.11

### Patch Changes

- Updated dependencies []:
  - @turnkey/crypto@2.11.2

## 0.6.10

### Patch Changes

- Updated dependencies []:
  - @turnkey/crypto@2.11.1

## 0.6.9

### Patch Changes

- Updated dependencies [[`c9a13f6`](https://github.com/tkhq/sdk/commit/c9a13f65092e9a7cddc0716206331db9a8b614d2)]:
  - @turnkey/crypto@2.11.0

## 0.6.8

### Patch Changes

- Updated dependencies []:
  - @turnkey/crypto@2.10.1

## 0.6.7

### Patch Changes

- Updated dependencies [[`ad044cd`](https://github.com/tkhq/sdk/commit/ad044cdcd41690c6479a81c56ebcd6d5108581fb)]:
  - @turnkey/crypto@2.10.0

## 0.6.6

### Patch Changes

- Updated dependencies [[`d677115`](https://github.com/tkhq/sdk/commit/d677115e60aaee53319131723541211457803317)]:
  - @turnkey/crypto@2.9.0

## 0.6.5

### Patch Changes

- Updated dependencies []:
  - @turnkey/crypto@2.8.14

## 0.6.4

### Patch Changes

- Updated dependencies []:
  - @turnkey/crypto@2.8.13

## 0.6.3

### Patch Changes

- Updated dependencies []:
  - @turnkey/crypto@2.8.12

## 0.6.2

### Patch Changes

- Updated dependencies []:
  - @turnkey/crypto@2.8.11

## 0.6.1

### Patch Changes

- Updated dependencies []:
  - @turnkey/crypto@2.8.10

## 0.6.0

### Minor Changes

- [#1135](https://github.com/tkhq/sdk/pull/1135) [`91d6a9e`](https://github.com/tkhq/sdk/commit/91d6a9eb1b9ac9e21745749615ac7a7be66f5cf6) Author [@ethankonk](https://github.com/ethankonk) - Exposed a `sign` method from the stamper for signing arbitrary payloads
  - Accepts a string payload and returns a signature in either `RAW` or `DER` format.

### Patch Changes

- Updated dependencies [[`d0dba04`](https://github.com/tkhq/sdk/commit/d0dba0412fa7b0c7c9b135e73cc0ef6f55187314)]:
  - @turnkey/crypto@2.8.9

## 0.5.0

### Minor Changes

- Updated dependencies [[`fc1d6e2`](https://github.com/tkhq/sdk/commit/fc1d6e2d26f4a53116633e9e8cccccd792267f4e), [`fc1d6e2`](https://github.com/tkhq/sdk/commit/fc1d6e2d26f4a53116633e9e8cccccd792267f4e), [`4880f26`](https://github.com/tkhq/sdk/commit/4880f26a4dd324c049bff7f35284098ccfc55823), [`c6ee323`](https://github.com/tkhq/sdk/commit/c6ee3239c389a7bbbbb23610c84b883ed298f95c), [`c6ee323`](https://github.com/tkhq/sdk/commit/c6ee3239c389a7bbbbb23610c84b883ed298f95c), [`c6ee323`](https://github.com/tkhq/sdk/commit/c6ee3239c389a7bbbbb23610c84b883ed298f95c), [`06347ad`](https://github.com/tkhq/sdk/commit/06347adfa08fb0867c350e43821d0fed06c49624), [`6bfcbc5`](https://github.com/tkhq/sdk/commit/6bfcbc5c098e64ab1d115518733b87cfc1653e17)]:
  - @turnkey/encoding@0.6.0

## 0.5.0-beta.6

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.6

## 0.5.0-beta.5

### Minor Changes

- SDK beta release @turnkey/react-wallet-kit @turnkey/core

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.5

## 0.4.8-beta.4

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.4

## 0.4.8-beta.3

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.3

## 0.4.8-beta.2

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.2

## 0.4.8-beta.1

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.1

## 0.4.8-beta.0

### Patch Changes

- Updated dependencies []:
  - @turnkey/encoding@0.6.0-beta.0

## 0.4.7

### Patch Changes

- [#698](https://github.com/tkhq/sdk/pull/698) [`7625df0`](https://github.com/tkhq/sdk/commit/7625df0538002c3455bd5862211210e38472e164) Author [@moeodeh3](https://github.com/moeodeh3) - Introduces an optional `runtimeOverride` parameter that allows the ability to explicitly specify the crypto environment: `"browser"`, `"node"`, or `"purejs"`.

## 0.4.6

### Patch Changes

- Updated dependencies [[`40c4035`](https://github.com/tkhq/sdk/commit/40c40359ec7096d0bca39ffc93e89361b3b11a1a)]:
  - @turnkey/encoding@0.5.0

## 0.4.5

### Patch Changes

- 4d1d775: Better error message and docstring for API key import

## 0.4.4

### Patch Changes

- 2d5977b: Update error messaging around api key and target public key usage

## 0.4.3

### Patch Changes

- Updated dependencies [e5c4fe9]
  - @turnkey/encoding@0.4.0

## 0.4.2

### Patch Changes

- Updated dependencies [93666ff]
  - @turnkey/encoding@0.3.0

## 0.4.1

### Patch Changes

- Changes: Resolves bugs where byte arrays might not be sufficiently padded (32 bytes are expected for x, y, and d elements of a JWK)

- Updated dependencies
  - @turnkey/encoding@0.2.1

## 0.4.0

### Minor Changes

- New PureJS implementation for `@turnkey/api-key-stamper`` to support React Native
- Introduce a dependency on `@turnkey/encoding` to consolidate utility functions

## 0.3.1

### Patch Changes

- Upgrade to Node v18 (#184)

## 0.3.0

### Minor Changes

- Use rollup to build ESM and CommonJS, fix ESM support (#174)

## 0.2.0

### Minor Changes

- Add ESM support (#154)

## 0.1.1

### Patch Changes

- Hint for web bundlers not to polyfill Node crypto

## 0.1.0

Initial release
